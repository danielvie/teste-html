import numpy as np
import pandas as pd
import re

def atmosisa(h):
    # [T, P, Vsom, rho] = atmosisa(h)
    # T    : temperatura [kelvin]
    # P    : pressao [pascal]
    # Vsom : velocidade som [m/s]
    # rho  : densidade [kg/m3]
    
    g     = 9.80665
    gamma = 1.4
    R     = 287.0531
    L     = 0.0065
    hts   = 11000
    htp   = 20000
    rho0  = 1.225
    P0    = 101325
    T0    = 288.15
    H0    = 0.0

    if (h > htp):
        h = htp
    
    if (h < H0):
        h = H0
    

    if (h > hts):
        T = T0 - L * hts
        expon = np.exp(g / (R * T) * (hts - h))
    else:
        T = T0 - L * h
        expon = 1.0
    

    a = np.sqrt(T * gamma * R)

    theta = T / T0

    P = P0 * pow(theta, (g / (L * R))) * expon
    rho = rho0 * pow(theta, ((g / (L * R)) - 1.0)) * expon

    vsom    = a

    return T, P, vsom, rho

def get_tiro_init():
    tiro = {
        # elementos de tiro
        'Elev_tiro': 942.0,
        'Azim_tiro': 0.0,
        'Sec_bal': 2,
        'Latitude': 5.0,

        # posicao da lancadora
        'Elau': 0.0,
        'Nlau': 0.0,
        'Alt_launch': 987.0,

        # posicao do alvo
        'Etarg': 0.0,
        'Ntarg': 45000.0,
        'Altarg': 987.0,

        # temperatura e pressao
        'T0': 8.6,
        'Proptemp': 20.0,
        'P0': 910.5,

        # altitude fieldguard e met
        'Altfg': 987.0,
        'Alt_met': 987.0,

        # vento de superficie
        'Vws': 0.0,
        'Azws': 0.0,

        # vento METCM
        'Metcm_included': 0,
        'Natm': 29,

        'Azwmetcm': [6380.0, 1400.0, 2240.0, 2670.0, 2540.0, 2570.0, 1680.0, 500.0, 6280.0, 6220.0, 6180.0, 240.0, 760.0, 1300.0, 920.0, 1520.0, 1640.0, 1160.0, 640.0, 500.0, 500.0, 990.0, 1900.0, 1460.0, 1670.0, 2880.0, 1070.0, 1490.0, 5020.0, 4540.0],
        'Vwmetcm': [3.0, 3.0, 8.0, 13.0, 11.0, 10.0, 10.0, 8.0, 8.0, 9.0, 12.0, 12.0, 11.0, 12.0, 15.0, 11.0, 14.0, 21.0, 25.0, 33.0, 45.0, 26.0, 27.0, 25.0, 10.0, 18.0, 20.0, 26.0, 13.0, 31.0],
        'Tent': [299.3, 300.7, 299.6, 296.5, 292.7, 289.5, 287.6, 285.0, 282.4, 280.5, 278.8, 276.0, 272.1, 265.4, 258.6, 251.5, 246.3, 237.3, 228.0, 219.8, 212.1, 204.4, 198.3, 193.0, 196.6, 199.7, 203.2, 208.4, 216.1, 216.8],
        'Pent': [1006.0, 994.0, 966.0, 923.0, 871.0, 821.0, 774.0, 729.0, 687.0, 646.0, 608.0, 572.0, 520.0, 458.0, 402.0, 352.0, 307.0, 266.0, 230.0, 197.0, 168.0, 143.0, 121.0, 101.0, 85.0, 72.0, 60.0, 47.0, 34.0, 25.0],

        # vento estimado
        'Vweth': 0.0,
        'Vwnth': 0.0,
        'Vweff': 0.0,
        'Vwnff': 0.0,
    }
    return tiro

class rastreio(object):
    def __init__(self):
        self.config = {}
        self.voo    = {}

def get_metcm(f):
    lin = ''
    mm  = []
    for _ in range(100):
        lin = f.readline()

        # condicao de saida
        if 'RESULTADOS' in lin:
            break

        colunas = lin.split()

        if len(colunas) < 2:
            continue
        elif not colunas[0].isnumeric():
            continue
        else:
            mm.append(colunas[1::])

    met = pd.DataFrame(mm, columns=['azi', 'vel', 'temp', 'pres'])
    return met.applymap(float)


def get_config(f):

    prefixo = ''
    flag_lateral = False
    config  = {}
    
    lin = ''

    while not re.search(r'.*MissionState.*Relative Time$', lin):
        lin   = f.readline()  # lendo linha
        
        # pulando linha em branco
        if (lin == '\n'):
            continue

        # guardando data
        if (lin.find('DATA:') != -1):
            res = re.search(r'\d{2}\/\d{2}\/\d{4}.+', lin).group(0)
            config['data'] = res
            continue

        # LENDO METCM
        if re.search(r'DIRECAO.+VELOCIDADE.+TEMPERATURA.+PRESSAO', lin):
            config['metcm'] = get_metcm(f)
            
        # MONTANDO PREFIXOS
        if re.search(r'^[\-\=\*][\w\s]+[\-\=\*]', lin):
            prefixo = ''

        # coordenadas do lancador
        if 'COORDENADAS DO LANCADOR' in lin:
            prefixo = 'lancador'
        elif 'COORDENADAS DO ALVO' in lin:
            prefixo = 'alvo'
        elif 'PONTO DE EXTRAPOLACAO' in lin:
            prefixo = 'extrapolacao'
        elif 'FIM DE QUEIMA' in lin:
            prefixo = 'fim de queima'
        elif 'PONTO DE IMPACTO' in lin:
            prefixo = 'impacto'

        # pulando linhas nao interessantes
        if not re.search(r'.{2,20}.+[:=]', lin):
            continue

        if re.search(r'^=', lin):
            continue

        # ENCONTRANDO NOME E VALOR PARA CASOS
        if 'Frontal' in lin:  # caso ventos
            if 'propulsada' in lin:
                prefixo = 'VentoTH'
            elif 'balistica' in lin:
                prefixo = 'VentoFF'

            nome  = '%s Frontal' % prefixo
            valor = re.sub(r'.*=', '', lin)
            flag_lateral = True

        elif flag_lateral:
            nome    = '%s Lateral' % prefixo
            valor   = re.sub(r'.*=', '', lin)
            prefixo = ''
            flag_lateral = False

        else:
            aux   = re.search(r'[\w\s\.]+(?=[\:\=])', lin)
            nome  = '%s %s' % (prefixo, aux.group(0))
            valor = lin[(aux.span(0)[1]+1)::]

        # trim espacos
        #valor = re.sub(r'(^\s+)|(\s+$)','',valor)
        valor = valor.strip()

        # ajustando nome
        nome = re.sub(r'Coordenada em (?=[xyz])', '', nome) # tirando 'Coordenada em'
        nome = re.sub(r'Extrapolacao em (?=[xyz])', '', nome) # tirando 'Extrapolacao em'

        nome = re.sub(r'(^\s+)|(\s+$)', '', nome)  # trim espacos
        nome = re.sub(r'[\W]+', '_', nome)  # subs nao caractere por '_'
        nome = re.sub(r'\_$', '', nome)  # remove '_' do final
        
        aux = ['', 0.]
        valor_num = float(re.sub(r'[^\-\+\d\.]', '', valor)) 

        aux[0] = valor_num
        aux[1] = valor

        config[nome.lower()] = aux

    # print(config)
    return config

def get_voo(f):
    
    txt = f.readlines()
    voo = {'dataset': [], 'missionstate': [], 'positionstate': [], 'measured_pos_x': [], 'measured_pos_y': [], 'measured_pos_z': [], 'one_sigma_x': [], 'one_sigma_y': [], 'one_sigma_z': [
    ], 'noise_ratio': [], 'filtered_pos_x': [], 'filtered_pos_y': [], 'filtered_pos_z': [], 'filtered_vel_x': [], 'filtered_vel_y': [], 'filtered_vel_z': [], 'relative_time': []}

    for t in txt:
        aux = t.split()

        if len(aux) != 17:
            continue

        voo['dataset'].append(aux[0])
        voo['missionstate'].append(aux[1])
        voo['positionstate'].append(aux[2])
        voo['measured_pos_x'].append(aux[3])
        voo['measured_pos_y'].append(aux[4])
        voo['measured_pos_z'].append(aux[5])
        voo['one_sigma_x'].append(aux[6])
        voo['one_sigma_y'].append(aux[7])
        voo['one_sigma_z'].append(aux[8])
        voo['noise_ratio'].append(aux[9])
        voo['filtered_pos_x'].append(aux[10])
        voo['filtered_pos_y'].append(aux[11])
        voo['filtered_pos_z'].append(aux[12])
        voo['filtered_vel_x'].append(aux[13])
        voo['filtered_vel_y'].append(aux[14])
        voo['filtered_vel_z'].append(aux[15])
        voo['relative_time'].append(aux[16])

    voo = pd.DataFrame(voo, columns=['dataset', 'missionstate', 'positionstate', 'measured_pos_x', 'measured_pos_y', 'measured_pos_z', 'one_sigma_x', 'one_sigma_y', 'one_sigma_z', 
    'noise_ratio', 'filtered_pos_x', 'filtered_pos_y', 'filtered_pos_z', 'filtered_vel_x', 'filtered_vel_y', 'filtered_vel_z', 'relative_time'], dtype=float)
    return voo

def ler_nedt(addr):
    with open(addr, 'r') as f:        
        config = get_config(f)
        voo    = get_voo(f)
    
    r = rastreio()
    r.config = config
    r.voo    = voo
    return r

def ler_edt_antiga(addr):

    # gerando padrao de dados de rastreio
    patt_rastreio = re.compile(
        r"(?P<time>\d+\.\d+)\t\s*"
        r"(?P<alfa>\S+)\t\s*"
        r"(?P<lamb>\S+)\t\s*"
        r"(?P<rang>\S+)\t\s*"
        r"(?P<alfa_e>\S+)\t\s*"
        r"(?P<lamb_e>\S+)\t\s*"
        r"(?P<rang_e>\S+)\t\s*"
        r"(?P<window>\S+)\t\s*"
        r"(?P<lockon>\S+)\t\s*"
        r"(?P<x_p>\S+)\t\s*"
        r"(?P<y_p>\S+)\t\s*"
        r"(?P<z_p>\S+)\t\s*"
        r"(?P<vt_p>\S+)\t\s*"
        r"(?P<x_pa>\S+)\t\s*"
        r"(?P<y_pa>\S+)\t\s*"
        r"(?P<z_pa>\S+)\t\s*"
        r"(?P<vt_pa>\S+)\t\s*"
        r"(?P<ctime>\S+)\t\s*"
        r"(?P<cz_p>\S+)\t\s*"
        r"(?P<vmt_p>\S+)\t\s*"
        r"(?P<cz_pa>\S+)\t\s*"
        r"(?P<vmt_pa>\S+)\t\s*"
        r"(?P<timeb>\S+)\t\s*"
        r"(?P<x_s>\S+)\t\s*"
        r"(?P<y_s>\S+)\t\s*"
        r"(?P<z_s>\S+)\t\s*"
        r"(?P<x_a>\S+)\t\s*"
        r"(?P<y_a>\S+)\t\s*"
        r"(?P<z_a>\S+)\t\s*"
        r"(?P<vx_a>\S+)\t\s*"
        r"(?P<vy_a>\S+)\t\s*"
        r"(?P<vz_a>\S+)\t\s*"
        r"(?P<vt_a>\S+)"
    )

    # gerando padrao de dados de configuracao
    patt_config = re.compile(
        r"#\s(?P<label>[\w\-]+)\..+\:\s+"
        r"(?P<value>\S+)"
    )

    # gerando padrao de dados de configuracao [array]
    patt_config_v = re.compile(
        r"#\s(?P<label>\w+)\..+\:\s+"
        r"(?P<value>[\-\+\d\.]+\t.+)"
    )

    # lendo arquivo
    V = []
    C = {}
    cols = None

    with open(addr) as f:
        for line in f:
            li = line.lstrip()
            
            # testando linha
            match_r  = patt_rastreio.match(li)
            match_c  = patt_config.match(li)
            match_cv = patt_config_v.match(li)
            
            # lendo config array
            if match_cv:
                vv = match_cv.groupdict()
                
                value = [v.lstrip() for v in vv['value'].split('\t')]
                try:
                    value = [float(v) for v in value[0:-1]]
                except:
                    pass
                                            
                C[vv['label']] = value
                continue        
            
            # lendo config
            if match_c:
                vv = match_c.groupdict()
                
                value = vv['value']
                try:
                    value = float(value)
                except:
                    pass
                C[vv['label']] = value
            
            # lendo rastreio
            if match_r:
                # agrupando match
                vv = match_r.groupdict()
                
                # lendo nomes rastreio
                if not cols:
                    cols = [v for v in vv]
                
                # lendo valores rastreio            
                V.append([vv[v] for v in vv])

    # criando dataframe com rastreio
    D = pd.DataFrame(V, columns=cols, dtype=float)

    res = {
        'radar': D,
        'config': C
    }
    
    return res