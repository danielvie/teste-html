import numpy as np
import pandas as pd
import re

def print_metcm(txt = ""):
    import clipboard

    if txt == "":
        txt = clipboard.paste()

    texto = txt.split('\n')

    vel  = []
    azi  = []
    pres = []
    temp = []
    
    for t in texto:
        if 'METCM' in t:
            continue
        if '99999' in t:
            break
        
        vel.append('{:.0f}'.format(float(t[2:5])*10))
        azi.append('{:.0f}'.format(float(t[5:8])))
        temp.append('{:.1f}'.format(float(t[9:13])/10))
        pres.append('{:.0f}'.format(float(t[13:17])))

    
    print('\'Natm\': {:d},'.format(len(vel) - 1))
    print('\'Vwmetcm\': ['+', '.join(azi)+'],')
    print('\'Azwmetcm\': ['+', '.join(vel)+'],')
    print('\'Tent\': ['+', '.join(temp)+'],')
    print('\'Pent\': ['+', '.join(pres)+'],')

def print_metcm_tab(nedt):
    tiro = nedt.tiro
    Vwmetcm  = tiro['Vwmetcm']
    Azwmetcm = tiro['Azwmetcm']
    Tent     = tiro['Tent']
    Pent     = tiro['Pent']

    d = pd.DataFrame(np.column_stack([Vwmetcm,Azwmetcm,Tent,Pent]), columns=['Vwmetcm','Azwmetcm','Tent','Pent'])
    print(d)
    # for vw,az,t,p in zip(Vwmetcm,Azwmetcm,Tent,Pent):
    #     print(vw,az,t,p)

def print_cpp(obj, copy = False):
    tiro = obj.tiro
    fog  = obj.fog

    txt  = ''
    txt += '//  Configurando FOG:\n'
    txt += 'int fog = {};\n'.format(fog)
    txt += 'nedt->ConfigEdt(fog);\n'

    txt += '\n'

    txt += '//  Elementos de Tiro:\n'
    txt += 'nedt->edtData.Elau       = {:.1f}; // Leste lancadora\n'.format(tiro['Elau'])
    txt += 'nedt->edtData.Nlau       = {:.1f}; // Norte lancadora\n'.format(tiro['Nlau'])
    txt += 'nedt->edtData.Alt_launch = {:.1f}; // Alti. lancadora\n'.format(tiro['Alt_launch'])
    txt += 'nedt->edtData.Latitude   = {:.1f}; // Latitude\n'.format(tiro['Latitude'])
    
    txt += '\n'

    txt += 'nedt->edtData.Etarg      = {:.1f}; // Leste alvo\n'.format(tiro['Etarg'])
    txt += 'nedt->edtData.Ntarg      = {:.1f}; // Norte alvo\n'.format(tiro['Ntarg'])
    txt += 'nedt->edtData.Altarg     = {:.1f}; // Alti. alvo\n'.format(tiro['Altarg'])

    txt += '\n'

    txt += 'nedt->edtData.Alt_met    = {:.1f}; // Alti. MET\n'.format(tiro['Alt_met'])
    txt += 'nedt->edtData.Altfg      = {:.1f}; // Alti. UCF\n'.format(tiro['Altfg'])

    txt += '\n'

    txt += 'nedt->edtData.T0         = {:.1f}; // Temperatura\n'.format(tiro['T0'])
    txt += 'nedt->edtData.Proptemp   = {:.1f}; // T. Propelente\n'.format(tiro['Proptemp'])
    txt += 'nedt->edtData.P0         = {:.1f}; // Pressao\n'.format(tiro['P0'])

    txt += '\n'

    txt += 'nedt->edtData.Sec_bal    = {:d}; // Balistica Sec.\n'.format(tiro['Sec_bal'])

    txt += '\n'

    txt += 'nedt->edtData.Latitude   = {}; // Latitude\n'.format(tiro['Latitude'])

    txt += '\n'

    txt += '// Vento de Superficie:\n'
    txt += 'nedt->edtData.Vws        = {:.1f}; // Vel.Vento Sup.\n'.format(tiro['Vws'])
    txt += 'nedt->edtData.Azws       = {:.1f}; // Az. Vento Sup.\n'.format(tiro['Azws'])

    txt += '\n'

    txt += '// METCM:\n'
    txt += 'nedt->edtData.Metcm_included = {:d};\n'.format(tiro['Metcm_included'])
    txt += 'nedt->edtData.Natm = {:d};\n'.format(tiro['Natm'])
    
    txt += '\n'
    txt_vel  = ''
    txt_azi  = ''
    txt_temp = ''
    txt_pres = ''
    for i in range(tiro['Natm'] + 1):
        txt_vel  += 'nedt->edtData.Vwmetcm[{:d}] = {}; '.format(i, tiro['Vwmetcm'][i])
        txt_azi  += 'nedt->edtData.Azwmetcm[{:d}] = {}; '.format(i, tiro['Azwmetcm'][i])
        txt_temp += 'nedt->edtData.Tent[{:d}] = {}; '.format(i, tiro['Tent'][i])
        txt_pres += 'nedt->edtData.Pent[{:d}] = {}; '.format(i, tiro['Pent'][i])
    
    txt += txt_vel+'\n'
    txt += txt_azi+'\n'
    txt += txt_temp+'\n'
    txt += txt_pres+'\n'

    txt += '\n'

    txt += '//  Calculo de Tiro :\n'
    txt += 'nedt->edtData.Elev_tiro      = {:.2f};\n'.format(tiro['Elev_tiro'])
    txt += 'nedt->edtData.Azim_tiro      = {:.2f};\n'.format(tiro['Azim_tiro'])
    txt += 'nedt->edtData.Fusetime_input = {:.2f};\n'.format(tiro['Fusetime_input'])

    if copy == True:
        import clipboard
        clipboard.copy(txt)
    else:
        print(txt)