import fg_engine
from fg_utils import deg2utm, utm2deg, lla2flat

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class ModelData (object):
    def __init__(self, name, value, alias):
        self.__value = value
        self.__name  = name
        self.__alias = alias        
        
    @property
    def value(self):
        # return fg_engine.get_edtdata(self.__name)
        return self.__value

    @value.setter
    def value(self, value):
        if not np.isscalar(value):
            value_ = [0.]*41
            value_[:len(value)] = value
            value = np.array(value_)

        self.__value = value
        fg_engine.set_data(self.__name,value)

    @value.deleter
    def value(self):
        del self.__value

class fg(object):
    """ CONSTRUCTOR """
    def __init__(self):
        self.__lancamento = []
        self.__inercia = []
        self.__propelente = []
        self.__geometria = []
        self.__dados_part = []
        self.__dados_vento = []
        self.__dados_empuxo = []
        self.__controle = []
        self.__flag_controle_on = 1
        self.__flag_vento_on = 1
        self._utm_zone = 23
        self._utm_hemis = 'S'
        self.__lmu_utm = []
        self.__lmu_deg = []
        self.__alvo_utm = []
        self.__alvo_deg = []
        self._met_alt = (0.0, 200.0, 500.0, 1000.0, 1500.0, 2000.0, 2500.0, 3000.0, 3500.0, 4000.0, 
                         4500.0, 5000.0, 6000.0, 7000.0, 8000.0, 9000.0, 10000.0, 11000.0, 12000.0, 
                         13000.0, 14000.0, 15000.0, 16000.0, 17000.0, 18000.0, 19000.0, 20000.0, 
                         21000.0, 22000.0, 23000.0, 24000.0, 25000.0, 26000.0, 27000.0, 28000.0, 
                         29000.0, 30000.0, 31000.0, 32000.0, 33000.0, 34000.0, 35000.0, 36000.0, 
                         37000.0, 38000.0, 39000.0, 40000.0, 41000.0)
        self.__vento_met_alt = []
        self.__vento_met_vel_knot = []
        self.__vento_met_azi_mils = []
        self.__vento_met_vel = []
        self.__vento_met_azi = []
        self.__vento_sup_vel_knot = []
        self.__vento_sup_azi_mils = []
        self.__vento_sup_vel = []
        self.__vento_sup_azi = []

        self.__elev = 0.0
        self.__azi  = 0.0

        self.__flags = []
        self.__used_list = dict()
        
        # constantes de conversao
        self.__deg = 180.0/np.pi
        self.__knot2ms = 0.514444
        
        self.V = []

        fg_engine.start()


    """ PROPERTIES """
    @property
    def deg(self):
        return self.__deg
    
    @property
    def knot2ms(self):
        return self.__knot2ms
    
    @property
    def lancamento(self):
        self.__lancamento = self.get_lancamento()
        return self.__lancamento
    
    @lancamento.setter
    def lancamento(self, value):
        for v in value:
            self.set_data(v, value[v])            
    
    @property
    def elev(self):
        self.__elev = self.get_data('Elev')
        return self.__elev
    
    @elev.setter
    def elev(self, value):
        self.set_data('Elev', value)
    
    @property
    def azi(self):
        self.__azi = self.get_data('Azi')
        return self.__azi
    
    @azi.setter
    def azi(self, value):
        self.set_data('Azi', value)

    @property
    def lmu_utm(self):
        self.__lmu_utm = self.get_lmu_utm()
        return self.__lmu_utm
    
    @lmu_utm.setter
    def lmu_utm(self, value):
        self.set_lmu_utm(value)
    
    @property
    def lmu_deg(self):
        self.__lmu_deg = self.get_lmu_deg()
        return self.__lmu_deg
    
    @lmu_deg.setter
    def lmu_deg(self, value):
        self.set_lmu_deg(value)
    
    @property
    def alvo_utm(self):
        self.__alvo_utm = self.get_alvo_utm()
        return self.__alvo_utm
    
    @alvo_utm.setter
    def alvo_utm(self, value):
        self.set_alvo_utm(value)
    
    @property
    def alvo_deg(self):
        self.__alvo_deg = self.get_alvo_deg()
        return self.__alvo_deg
    
    @alvo_deg.setter
    def alvo_deg(self, value):
        self.controle = {'alvo': value}
    
    @property
    def vento_met_alt(self):
        self.__vento_met_alt = self.dados_vento['altitude']
        return self.__vento_met_alt
    
    @vento_met_alt.setter
    def vento_met_alt(self, value):
        if np.isscalar(value):
            value = [value]
        self.dados_vento = {'altitude': value}
    
    @property
    def vento_met_vel_knot(self):
        value = self.dados_vento['velocidade']
        self.__vento_met_vel_knot = np.multiply(value, 1./self.knot2ms)
        return self.__vento_met_vel_knot
    
    @vento_met_vel_knot.setter
    def vento_met_vel_knot(self, value):
        if np.isscalar(value):
            value = [value]
        vel = np.multiply(value, self.knot2ms)
        self.dados_vento = {'velocidade': vel}
    
    @property
    def vento_met_vel(self):
        return self.dados_vento['velocidade']
    
    @vento_met_vel.setter
    def vento_met_vel(self, value):
        if np.isscalar(value):
            value = [value]
        self.dados_vento = {'velocidade': value}
    
    @property
    def vento_sup_vel_knot(self):
        return self.vento_met_vel_knot[0]
    
    @vento_sup_vel_knot.setter
    def vento_sup_vel_knot(self, value):
        vel    = self.dados_vento['velocidade']
        vel[0] = np.multiply(value, self.knot2ms)
        self.dados_vento = {'velocidade': vel}
    
    @property
    def vento_sup_vel(self):
        return self.vento_met_vel[0]
    
    @vento_sup_vel.setter
    def vento_sup_vel(self, value):
        vel    = self.dados_vento['velocidade']
        vel[0] = value
        self.dados_vento = {'velocidade': vel}
    
    @property
    def vento_met_azi_mils(self):
        value = self.dados_vento['azimute']
        self.__vento_met_azi_mils = np.multiply(value, 1./0.05625)
        return self.__vento_met_azi_mils
    
    @vento_met_azi_mils.setter
    def vento_met_azi_mils(self, value):
        if np.isscalar(value):
            value = [value]
        azi = np.multiply(value, 0.05625)
        self.dados_vento = {'azimute': azi}
    
    @property
    def vento_met_azi(self):
        return self.dados_vento['azimute']
    
    @vento_met_azi.setter
    def vento_met_azi(self, value):
        if np.isscalar(value):
            value = [value]
        self.dados_vento = {'azimute': value}

    @property
    def vento_sup_azi_mils(self):
        return self.vento_met_azi_mils[0]
    
    @vento_sup_azi_mils.setter
    def vento_sup_azi_mils(self, value):
        azi    = self.dados_vento['azimute']
        azi[0] = np.multiply(value, 0.05625)
        self.dados_vento = {'azimute': azi}
    
    @property
    def vento_sup_azi(self):
        return self.vento_met_azi[0]
    
    @vento_sup_azi.setter
    def vento_sup_azi(self, value):
        azi    = self.dados_vento['azimute']
        azi[0] = value
        self.dados_vento = {'azimute': azi}

    @property
    def controle(self):
        self.__controle = self.get_controle()
        return self.__controle
    
    @controle.setter
    def controle(self, value):
        for v in value:
            self.set_data(f'controle/{v}', value[v]) 

    @property
    def inercia(self):
        self.__inercia = self.get_inercia()
        return self.__inercia
    
    @inercia.setter
    def inercia(self, value):
        for v in value:
            self.set_data(v, value[v])       
    
    @property
    def propelente(self):
        self.__propelente = self.get_propelente()
        return self.__propelente
    
    @propelente.setter
    def propelente(self, value):
        for v in value:
            self.set_data(v, value[v])       

    @property
    def geometria(self):
        self.__geometria = self.get_geometria()
        return self.__geometria
    
    @geometria.setter
    def geometria(self, value):
        for v in value:
            self.set_data(v, value[v])

    @property
    def dados_part(self):
        self.__dados_part = self.get_dados_part()
        return self.__dados_part
    
    @dados_part.setter
    def dados_part(self, value):
        for v in value:
            self.set_data(v, value[v])       
    
    @property
    def dados_vento(self):
        self.__dados_vento = self.get_dados_vento()
        return self.__dados_vento
    
    @dados_vento.setter
    def dados_vento(self, value):
        for v in value:
            self.set_data(f'vento/{v}', value[v])

    @property
    def dados_empuxo(self):
        self.__dados_empuxo = self.get_dados_empuxo()
        return self.__dados_empuxo
    
    @dados_empuxo.setter
    def dados_empuxo(self, value):
        for v in value:
            self.set_data(f'empuxo/{v}', value[v])
    
    @property
    def flags(self):
        self.__flags = self.get_flags()
        return self.__flags
    
    @flags.setter
    def flags(self, value):
        for v in value:
            self.set_data(f'flag/{v}', value[v])

    @property
    def flag_controle_on(self):
        self.__flag_controle_on = self.flags['controle_on']
        return self.__flag_controle_on
    
    @flag_controle_on.setter
    def flag_controle_on(self, value):
        self.flags = {'controle_on':value}
    
    @property
    def flag_vento_on(self):
        self.__flag_vento_on = self.flags['vento_on']
        return self.__flag_vento_on
    
    @flag_vento_on.setter
    def flag_vento_on(self, value):
        self.flags = {'vento_on':value}
       
    """ METHODS """

    def init(self):
        fg_engine.init()

    def start(self):
        fg_engine.start()

    def restart(self):
        # guardando configuracoes do modelo
        lanc0 = self.lancamento
        cont0 = self.controle
        flag0 = self.flags
        vent0 = self.dados_vento
        iner0 = self.inercia
        
        # inicializando modelo
        self.init()
        
        # restaurando configuracoes do modelo
        self.lancamento  = lanc0
        self.controle    = cont0
        self.flags       = flag0
        self.dados_vento = vent0
        self.inercia     = iner0
        
        # iniciando flag de tiro
        self.start()

    def reset(self):
        self.restart()

    def access_data(self, name, alias = ''):
        if alias == '':
            alias = name

        value = self.get_data(name)
        data  = ModelData(name, value, alias)

        self.__used_list[name] = alias

        setattr(self, alias, data)
        self.__dict__[alias] = data

    def run(self):
        # guardando vento
        vento_vel = self.dados_vento['velocidade']
        if self.flags['vento_on'] == 0:
            self.dados_vento = {'velocidade': [0.]}
            pass

        # executando trajetoria        
        res = fg_engine.run()

        # restaurando vento        
        if self.flags['vento_on'] == 0:
            self.dados_vento = {'velocidade': vento_vel}

        # lendo dados simulacao
        D   = pd.DataFrame(res, columns=['t','x','y','z','vx','vy','vz','phi','theta','psi','u','v','w','p','q','r','lat','lon','canard_on','canard_u1','canard_u2','canard_y1','canard_y2'])
        
        # ajustando saidas
        D['canard_u1_deg'] = D.canard_u1.mul(self.__deg)
        D['canard_u2_deg'] = D.canard_u2.mul(self.__deg)
        D['canard_y1_deg'] = D.canard_y1.mul(self.__deg)
        D['canard_y2_deg'] = D.canard_y2.mul(self.__deg)
        D['lat_deg'] = D.lat.mul(self.__deg)
        D['lon_deg'] = D.lon.mul(self.__deg)
        D['h']    = D.z.mul(-1.0)
        D['alc']  = np.hypot(D.x, D.y)
        D['vtot'] = np.sqrt(D.vx**2 + D.vy**2 + D.vz**2)
        
        # adicionando coordenadas Este Norte
        en     = lla2flat(D.lat_deg, D.lon_deg, D.h.values)
        D['e'] = en.e
        D['n'] = en.n

        # salvando voo
        # TODO: implementar valores de trajetoria em coordenadas polares.
        self.V = D

        return D
    
    def voar(self):
        self.restart()
        r = self.run()
        return r

    def get_utm(self):
        # lendo trajetoria de voo
        v = self.V
        if len(v) == 0:
            v = self.voar()
        
        utm = []
        
        for la, lo in zip(v.lat, v.lon):

            aux = deg2utm(la*self.__deg, lo*self.__deg)
            utm.append([aux[0], aux[1]])

        utm = pd.DataFrame(utm, columns=['e', 'n'])
        return utm
    
    def get_flat(self):
        # lendo trajetoria de voo
        v = self.V
        if len(v) == 0:
            v = self.voar()
        
        flat = []
        
        # lla0 = (v.lat_deg.values[0], v.lon_deg.values[0])
        # for lat, lon, h in zip(v.lat_deg, v.lon_deg, v.h):

        #     aux = lla2flat((lat, lon, h), lla0)
        #     flat.append([aux[1], aux[0]])

        # flat = pd.DataFrame(flat, columns=['e', 'n'])
        flat = lla2flat(v.lat_deg, v.lon_deg, v.h)
        return flat

    def get_alvo_flat(self):
        alvo = lla2flat(*self.alvo_deg, self.lmu_deg[0:2])

        return (alvo.e.values[0], alvo.n.values[0], alvo.h.values[0])

    def set_data(self, name, value):
        if np.isscalar(value):
            fg_engine.set_data(name, value)
        else:
            fg_engine.set_data(name, [v for v in value])

    def get_data(self, name): 
        value = fg_engine.get_data(name)
        return value
    
    def get_lancamento(self):
        N = ('Elev','Rlat','Rlong','Ralt','Azi','Talt','Tesp','Hsub','Hmet','Rtemp','Rde','Dbal','Tbal','Pbal','Phi0')

        lancamento = {n:self.get_data(n) for n in N}
        return lancamento

    def get_inercia(self):
        N = ('Mf','Xf','Yf','Zf','Ixf','Iyf','Izf','Ixyf','Ixzf','Iyzf','Fgrot','Fog','Ixemp_fech','Kc','Tabin','Tabre','A2','A5','A9','A10')

        inercia = {n:self.get_data(n) for n in N}
        return inercia

    def get_propelente(self):
        propelente = {
            'Mp0': self.get_data('Mp0'),
            'Xp': self.get_data('Xp'),
            'Yp': self.get_data('Yp'),
            'Zp': self.get_data('Zp'),
            'Ixyp': self.get_data('Ixyp'),
            'Ixzp': self.get_data('Ixzp'),
            'Iyzp': self.get_data('Iyzp'),
            'Dp': self.get_data('Dp'),
            'Lp': self.get_data('Lp'),
            'Rop': self.get_data('Rop'),
            'Tb0': self.get_data('Tb0'),
            'T_trans': self.get_data('T_trans'),
            'E0': self.get_data('E0'),
            'Ye': self.get_data('Ye'),
            'Ze': self.get_data('Ze'),
            'Alfaj': self.get_data('Alfaj'),
            'Betaj': self.get_data('Betaj'),
            'Ae': self.get_data('Ae'),
            'Grot0': self.get_data('Grot0'),
            'Kcan': self.get_data('Kcan'),
        }
        return propelente

    def get_geometria(self):
        N = ('Dr','Lb','Be','Ce','Fe','De0','Flat','Fnor','Retemp','Wabre','Dalfog0')
        geometria = {n:self.get_data(n) for n in N}
        return geometria

    def get_dados_part(self):
        
        N = ('Xt1', 'Xt2', 'Xt3', 'Xfim', 'Dlan', 'Ktubo', 'Rt', 'Lr', 'Mir', 'Xboca', 'Memp', 'Cemp', 'Demp', 'Aemp', 'Cemp0', 'Cemp1', 'Cemp2', 'Cemp3', 'Ixemp', 'Fcdsub', 'Dsub', 'Msub', 'Xac', 'Yac', 'Zac')
        dados_part = {n:self.get_data(n) for n in N}

        return dados_part
            
    def get_flags(self):
        flags = {
            'controle_on': self.get_data('flag/controle_on'),
            'canard_fail_1': self.get_data("flag/canard_fail_1"),
            'canard_fail_2': self.get_data("flag/canard_fail_2"),
            'canard_fail_ang_1': self.get_data("flag/canard_fail_ang_1"),
            'canard_fail_ang_2': self.get_data("flag/canard_fail_ang_2"),
            'vento_on': self.__flag_vento_on
        }
        return flags

    def get_controle(self):
        controle = {
            'alvo': [x for x in self.get_data('controle/alvo')],
            'dh_alvo': self.get_data('controle/dh_alvo'),
            't_canard': self.get_data('controle/t_canard'),
            'cd_subm': self.get_data('controle/cd_subm'),
            'ganhos': [x for x in self.get_data('controle/ganhos')],
            'ganhos_std': [x for x in self.get_data('controle/ganhos_std')],
        }
        return controle

    def get_dados_empuxo(self):
        empuxo = {
            'Tempo': self.get_data('empuxo/Tempo'),
            'Empuxo': self.get_data('empuxo/Empuxo'),
            'Grot': self.get_data('empuxo/Grot'),
        }
        return empuxo

    def get_dados_vento(self):
        vento = {
            'altitude': self.get_data('vento/altitude'),
            'azimute': self.get_data('vento/azimute'),
            'velocidade': self.get_data('vento/velocidade'),
        }
        return vento

    def get_voo(self):
        return self.V

    def get_impacto_pos(self):
        # lendo dados 'voo'
        v = self.V

        # lendo ultimo ponto
        impacto = [v['x'].values[-1], v['y'].values[-1], v['h'].values[-1]]

        return impacto
    
    def get_impacto_lla(self):
        # lendo dados 'voo'
        v = self.V

        # lendo ultimo ponto
        impacto = [v['lat'].values[-1]*self.deg, v['lon'].values[-1]*self.deg, v['h'].values[-1]]

        return impacto
    
    def get_impacto_utm(self):
        # lendo dados 'voo'
        la, lo, h = self.get_impacto_lla()

        # convertendo para 'utm'
        e, n, _, _ = deg2utm(la, lo)

        # lendo ultimo ponto
        impacto = [e, n, h]

        return impacto
    
    def get_lmu_utm(self):
        deg  = 180.0/np.pi
        lanc = self.lancamento
        la   = lanc['Rlat']*deg
        lo   = lanc['Rlong']*deg
        h    = lanc['Ralt']

        (e,n,_,_) = deg2utm(la, lo)

        lmu = [e, n, h]
        return lmu

    def get_lmu_deg(self):
        
        lanc = self.lancamento
        la   = lanc['Rlat']*self.deg
        lo   = lanc['Rlong']*self.deg
        h    = lanc['Ralt']

        return (la, lo, h)

    def set_lmu_utm(self, value):
        (la, lo) = utm2deg(value[0], value[1], self._utm_zone, self._utm_hemis)
        lanc = {
            'Rlat': la/self.deg,        
            'Rlong': lo/self.deg,
        }
        
        if len(value) == 3:
            lanc['Ralt'] = value[2]
        
        self.lancamento = lanc
    
    def set_lmu_deg(self, value):
        
        lanc = {
            'Rlat': value[0]/self.deg,
            'Rlong': value[1]/self.deg,
        }
        
        if len(value) == 3:
            lanc['Ralt'] = value[2]
        
        self.lancamento = lanc
    
    def get_alvo_utm(self):
        contr = self.controle
        la   = contr['alvo'][0]
        lo   = contr['alvo'][1]
        h    = contr['alvo'][2]

        (e,n,_,_) = deg2utm(la, lo)

        controle = [e, n, h]
        return controle
    
    def get_alvo_deg(self):
        contr = self.controle
        la   = contr['alvo'][0]
        lo   = contr['alvo'][1]
        h    = contr['alvo'][2]

        return (la, lo, h)

    def set_alvo_utm(self, value):
        (la, lo) = utm2deg(value[0], value[1], self._utm_zone, self._utm_hemis)
        
        if len(value) == 2:
            alvo = (la, lo, self.alvo_deg[2])
        elif len(value) == 3:
            alvo = (la, lo, value[2])
        
        self.controle = {'alvo': alvo}

    def get_config(self):
        config = {}
        config['lancamento']   = self.lancamento
        config['dados_part']   = self.dados_part
        config['dados_vento']  = self.dados_vento
        config['controle']     = self.controle
        config['dados_empuxo'] = self.dados_empuxo
        config['flags']        = self.flags
        config['inercia']      = self.inercia
        config['propelente']   = self.propelente

        return config
    
    def set_config(self, config):
        self.lancamento   = config['lancamento']
        self.dados_part   = config['dados_part']
        self.dados_vento  = config['dados_vento']
        self.controle     = config['controle']
        self.dados_empuxo = config['dados_empuxo']
        self.flags        = config['flags']
        self.inercia      = config['inercia']
        self.propelente   = config['propelente']

        return config
    
    def get_dgt(self):
        # posicoes
        lmu  = self.lmu_utm
        alvo = self.alvo_utm
        
        # calculando vetor diferenca
        vetor_alvo = np.subtract(alvo, lmu)[0:2]
        
        # calculando dgt
        dgt        = np.arctan2(vetor_alvo[0],vetor_alvo[1])*3200./np.pi
        
        # retorno
        return dgt

    def get_dist_alvo(self):
        lmu_utm        = self.get_lmu_utm()
        alvo_utm       = self.get_alvo_utm()
        
        alvo_utm[2]    = 0.0
        lmu_utm[2]     = 0.0
        
        vetor_alvo     = np.subtract(alvo_utm, lmu_utm)
        dist_alvo      = np.linalg.norm(vetor_alvo)
        
        return dist_alvo

    def get_desvio_lateral(self):
        lmu_utm        = self.get_lmu_utm()
        alvo_utm       = self.get_alvo_utm()
        impacto_utm    = self.get_impacto_utm()
        
        alvo_utm[2]    = 0.0
        lmu_utm[2]     = 0.0
        impacto_utm[2] = 0.0
        
        vetor_alvo     = np.subtract(alvo_utm, lmu_utm)
        vetor_impacto  = np.subtract(impacto_utm, lmu_utm)

        dist_alvo      = self.get_dist_alvo()
        
        desvio_lateral = np.cross(vetor_impacto, vetor_alvo)[2]/dist_alvo

        return desvio_lateral  
    
    def get_desvio_alcance(self):
        lmu_utm        = self.get_lmu_utm()
        alvo_utm       = self.get_alvo_utm()
        impacto_utm    = self.get_impacto_utm()
        
        alvo_utm[2]    = 0.0
        lmu_utm[2]     = 0.0
        impacto_utm[2] = 0.0
        
        vetor_alvo     = np.subtract(alvo_utm, lmu_utm)
        vetor_impacto  = np.subtract(impacto_utm, lmu_utm)

        dist_alvo      = self.get_dist_alvo()
        
        desvio_alcance = np.dot(vetor_alvo, vetor_impacto)/dist_alvo - dist_alvo

        return desvio_alcance

    def get_desvios(self):
        return (self.get_desvio_alcance(), self.get_desvio_lateral())

    def get_dist_impacto(self):
        lmu_utm        = self.get_lmu_utm()
        impacto_utm    = self.get_impacto_utm()
        
        alcance = np.linalg.norm(np.subtract(impacto_utm[0:2], lmu_utm[0:2]))
        return alcance

    def calc_densidade(self, temperatura, pressao):
        densidade = pressao*100/287.058/(temperatura + 273.15)
        return densidade

    def calcular_tiro(self, dx = 0.0, verbose = True):
        '''
        calcular_tiro2(self, dx = 0.0, verbose = True)
        '''

        # guardando configuracao flags
        flag0 = self.flags

        # desligando controle
        self.flag_controle_on = 0

        # gerando alvo
        ALVO = self.alvo_deg
        
        if dx > 0.01:
            lmu   = self.lmu_utm
            alvo  = self.alvo_utm

            dif   = np.subtract(alvo, lmu)
            norm  = np.linalg.norm(dif)
            alvo_ = dif/norm*(norm + dx) + lmu

            self.alvo_utm = alvo_            

        # parametros iniciais
        a     = 300.
        b     = 1100.
        azi   = self.get_dgt()
                
        # print texto inicial
        barra = '-'*60

        if verbose:        
            print('')
            print(barra)
            print(f'alcance nominal : {self.get_dist_alvo():.1f} m')
            print(f'dgt             : {azi:.1f} mils')
            print(barra)
            print('')

        # metodo de busca
        for i in range(15):
            # gerando estimativa
            x = (a + b)/2.
            
            # calculando trajetoria
            self.elev = x
            self.azi = azi
            self.voar()
            
            # calculo de desvios
            desvio_alcance = self.get_desvio_alcance()
            desvio_lateral = self.get_desvio_lateral()
            alcance        = self.get_dist_impacto()
            
            # calculo de erro
            erro     = desvio_alcance
            erro_azi = desvio_lateral/alcance*1000.0
            
            # correcao azi
            azi     -= erro_azi
            
            # imprimindo resultado da iteracao
            res = b - a

            if verbose:
                print(f'({i:02d})')
                print(f'elev, min, max, res      : ({x:.2f}, {a:.2f}, {b:.2f}, {res:.2f})')
                print(f'azi, erro_azi            : ({self.azi:.2f}, {erro_azi:.2f})')
                print(f'desvio alcance / lateral : ({desvio_alcance:.2f}, {desvio_lateral:.2f})')
                print('')
            
            # condicao de saida
            if np.all(np.abs([desvio_alcance, desvio_lateral]) < 1.0):
                if verbose:
                    print('condicao de saida acionado!')
                break
            
            # ajuste de limites
            if erro < 0.0:
                a = x
            else:
                b = x
        
        # restaurando configuracao flags
        self.flags = flag0
        self.alvo_deg = ALVO

        # imprimindo resultados
        if verbose:
            print('')
            print(barra)
        print(f'elev: {x:.2f}, azi: {azi:.2f}, tempo voo: {self.V["t"].values[-1]:.2f}')
    
    def calcular_tiro2(self, dx = 0.0, verbose = True):
        '''
        calcular_tiro2(self, dx = 0.0, verbose = True)
        '''

        # guardando configuracao flags
        flag0 = self.flags

        # desligando controle
        self.flag_controle_on = 0

        # gerando alvo
        ALVO = self.alvo_deg
        
        if dx > 0.01:
            lmu   = self.lmu_utm
            alvo  = self.alvo_utm

            dif   = np.subtract(alvo, lmu)
            norm  = np.linalg.norm(dif)
            alvo_ = dif/norm*(norm + dx) + lmu

            self.alvo_utm = alvo_            

        # parametros iniciais
        a     = 300.
        b     = 1100.
        azi   = self.get_dgt()
                
        # print texto inicial
        barra = '-'*60

        if verbose:        
            print('')
            print(barra)
            print(f'alcance nominal : {self.get_dist_alvo():.1f} m')
            print(f'dgt             : {azi:.1f} mils')
            print(barra)
            print('')

        # encontrando rmin
        rmin = 1e7
        rmax = 1e7

        # metodo de busca
        for i in range(15):
            # gerando estimativa
            if (rmin > 1e6) or (rmax > 1e6):
                x = (a + b)/2.
            else:
                perc = abs(rmin)/(rmax - rmin)
                x = perc*(b - a) + a
            
            # calculando trajetoria
            self.elev = x
            self.azi = azi
            self.voar()
            
            # calculo de desvios
            desvio_alcance = self.get_desvio_alcance()
            desvio_lateral = self.get_desvio_lateral()
            alcance        = self.get_dist_impacto()
            
            # calculo de erro
            erro     = desvio_alcance
            erro_azi = desvio_lateral/alcance*1000.0
            
            # correcao azi
            azi     -= erro_azi
            
            # imprimindo resultado da iteracao
            res = b - a

            if verbose:
                print(f'({i:02d})')
                print(f'elev, min, max, res      : ({x:.2f}, {a:.2f}, {b:.2f}, {res:.2f})')
                print(f'azi, erro_azi            : ({self.azi:.2f}, {erro_azi:.2f})')
                print(f'desvio alcance / lateral : ({desvio_alcance:.2f}, {desvio_lateral:.2f})')
                print('')
            
            # condicao de saida
            if np.all(np.abs([desvio_alcance, desvio_lateral]) < 1.0):
                if verbose:
                    print('condicao de saida acionado!')
                break
            
            # ajuste de limites
            if erro < 0.0:
                a = x
                rmin = desvio_alcance
            else:
                b = x
                rmax = desvio_alcance
        
        # restaurando configuracao flags
        self.flags = flag0
        self.alvo_deg = ALVO

        # imprimindo resultados
        if verbose:
            print('')
            print(barra)
            
        print(f'elev: {x:.2f}, azi: {azi:.2f}, tempo voo: {self.V["t"].values[-1]:.2f}')
    
    def plot_canard(self, nro_par = 1):
        v = self.V

        t = v['t']

        if nro_par == 1:
            u = v['canard_u1_deg']
            y = v['canard_y1_deg']
        else:
            u = v['canard_u2_deg']
            y = v['canard_y2_deg']

        plt.plot(t, u)
        plt.plot(t, y)
        plt.grid(1)

    def get_tiro_nedt(self):
        lmu  = self.lmu_utm
        alvo = self.alvo_utm
        lancamento = self.lancamento

        # calculo de pressao
        temperatura = lancamento['Rtemp']
        densidade   = lancamento['Rde']
        pressao = densidade/100*287.058*(temperatura + 273.15)

        tiro = {
            'Elau': lmu[0],
            'Nlau': lmu[1],
            'Alt_launch': lmu[2],
            'Latitude': 5.0,
            'Alt_met': lancamento['Hmet'],
            'Altfg': lmu[2],
            'Etarg': alvo[0],
            'Ntarg': alvo[1],
            'Altarg': alvo[2],
            'T0': temperatura,
            'Proptemp': temperatura,
            'P0': pressao,
            'Vws': 0.0,
            'Azws': 0.0,
            'Metcm_included': 0,
            'Natm': 0,
            'Vwmetcm': [0.],
            'Azwmetcm': [0.],
            'Tent': [0.],
            'Pent': [0.],
            'Elev_tiro': 942.0,
            'Azim_tiro': 0.0,
            'Fusetime_input': 0.0,
            'Sec_bal': 2,
            'Vweth': 0.0,
            'Vwnth': 0.0,
            'Vweff': 0.0,
            'Vwnff': 0.0,
            'RefDir': 0.0
        }
        return tiro

    def print_cpp(self, copy = False):
        tiro = self.get_tiro_nedt()
        fog  = 'ss40g'
        
        txt  = ''
        txt += '//  Configurando FOG:\n'
        txt += 'int fog = {};\n'.format(fog)
        txt += 'nedt->ConfigEdt(fog);\n'

        txt += '\n'

        txt += '//  Elementos de Tiro:\n'
        txt += 'nedt->edtData.Elau       = {:.1f}; // Leste lancadora\n'.format(tiro['Elau'])
        txt += 'nedt->edtData.Nlau       = {:.1f}; // Norte lancadora\n'.format(tiro['Nlau'])
        txt += 'nedt->edtData.Alt_launch = {:.1f}; // Alti. lancadora\n'.format(tiro['Alt_launch'])
        txt += 'nedt->edtData.Latitude   = {:.1f}; // Latitude\n'.format(tiro['Latitude'])
        
        txt += '\n'

        txt += 'nedt->edtData.Etarg      = {:.1f}; // Leste alvo\n'.format(tiro['Etarg'])
        txt += 'nedt->edtData.Ntarg      = {:.1f}; // Norte alvo\n'.format(tiro['Ntarg'])
        txt += 'nedt->edtData.Altarg     = {:.1f}; // Alti. alvo\n'.format(tiro['Altarg'])

        txt += '\n'

        txt += 'nedt->edtData.Alt_met    = {:.1f}; // Alti. MET\n'.format(tiro['Alt_met'])
        txt += 'nedt->edtData.Altfg      = {:.1f}; // Alti. UCF\n'.format(tiro['Altfg'])

        txt += '\n'

        txt += 'nedt->edtData.T0         = {:.1f}; // Temperatura\n'.format(tiro['T0'])
        txt += 'nedt->edtData.Proptemp   = {:.1f}; // T. Propelente\n'.format(tiro['Proptemp'])
        txt += 'nedt->edtData.P0         = {:.1f}; // Pressao\n'.format(tiro['P0'])

        txt += '\n'

        txt += 'nedt->edtData.Sec_bal    = {:d}; // Balistica Sec.\n'.format(tiro['Sec_bal'])

        txt += '\n'

        txt += 'nedt->edtData.Latitude   = {}; // Latitude\n'.format(tiro['Latitude'])

        txt += '\n'

        txt += '// Vento de Superficie:\n'
        txt += 'nedt->edtData.Vws        = {:.1f}; // Vel.Vento Sup.\n'.format(tiro['Vws'])
        txt += 'nedt->edtData.Azws       = {:.1f}; // Az. Vento Sup.\n'.format(tiro['Azws'])

        txt += '\n'

        txt += '// METCM:\n'
        txt += 'nedt->edtData.Metcm_included = {:d};\n'.format(tiro['Metcm_included'])
        txt += 'nedt->edtData.Natm = {:d};\n'.format(tiro['Natm'])
        
        txt += '\n'
        txt_vel  = ''
        txt_azi  = ''
        txt_temp = ''
        txt_pres = ''
        for i in range(tiro['Natm'] + 1):
            txt_vel  += 'nedt->edtData.Vwmetcm[{:d}] = {}; '.format(i, tiro['Vwmetcm'][i])
            txt_azi  += 'nedt->edtData.Azwmetcm[{:d}] = {}; '.format(i, tiro['Azwmetcm'][i])
            txt_temp += 'nedt->edtData.Tent[{:d}] = {}; '.format(i, tiro['Tent'][i])
            txt_pres += 'nedt->edtData.Pent[{:d}] = {}; '.format(i, tiro['Pent'][i])
        
        txt += txt_vel+'\n'
        txt += txt_azi+'\n'
        txt += txt_temp+'\n'
        txt += txt_pres+'\n'

        txt += '\n'

        txt += '//  Calculo de Tiro :\n'
        txt += 'nedt->edtData.Elev_tiro      = {:.2f};\n'.format(tiro['Elev_tiro'])
        txt += 'nedt->edtData.Azim_tiro      = {:.2f};\n'.format(tiro['Azim_tiro'])
        txt += 'nedt->edtData.Fusetime_input = {:.2f};\n'.format(tiro['Fusetime_input'])

        if copy == True:
            import clipboard
            clipboard.copy(txt)
        else:
            print(txt)