import nedt_engine
import nedt_print
import nedt_utils

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import re

class ModelData (object):
    def __init__(self, model, name, value, alias):
        self.__model = model
        self.__value = value
        self.__name  = name
        self.__alias = alias        
        
    @property
    def value(self):
        self.__value = nedt_engine.get_data(self.__model, self.__name)
        return self.__value

    @value.setter
    def value(self, value):
        if not np.isscalar(value):
            value_ = [0.]*41
            value_[:len(value)] = value
            value = np.array(value_)

        self.__value = value
        nedt_engine.set_data(self.__model, self.__name, value)

    @value.deleter
    def value(self):
        del self.__value

class nedt:
    def __init__(self):
        self.__model       = 0
        self.__fog         = 'SS_60'
        self.__rec         = 0
        
        self.__met         = 0
        self.__met_natm    = 0
        self.__met_vel     = []
        self.__met_azi     = []
        self.__met_temp    = []
        self.__met_press   = []
        self.__met_h       = 0.
        self.__vsup_vel    = 0.
        self.__vsup_azi    = 0.
        
        self.__fg_h        = 0.
        self.__temp        = 0.
        self.__pressao     = 0.
        self.__proptemp    = 0.

        self.__bdt_mass    = 0.
        self.__bdt_emax    = 0.
        self.__bdt_emin    = 0.

        self.__alvo        = []
        self.__lmu         = []
        self.__secb        = 0
        self.__fuze        = 0.0
        self.__elev        = 0.0
        self.__azi         = 0.0
        self.__err         = 0
        self.__tiro        = {}
        self.__tiro0       = {}
        self.__teng0       = {}
        self.__props       = {}
        self.__bdt         = {}
        self.__impacto     = {}
        self.__teng        = {}
        self.__teng_th     = 1.0 # ajuste de engenharia em empuxo
        self.__teng_cd     = 1.0 # ajuste de engenharia em arrasto
        self.__trackdata   = []
        self.__trackconfig = []
        self.__used_list   = dict()

        self.start()
        
    def start(self):
        if self.__model:
            self.engine_unload()

        self.__model = self.engine_load()
        tiro = nedt_utils.get_tiro_init()
        
        self.tiro  = tiro
        self.__tiro0 = tiro
        self.__teng0 = self.teng
        nedt_engine.config_edt(self.__model, self.__fog)
    
    def get_tiro0(self):
        return self.__tiro0

    def copy(self):
        # criando objeto
        import nedt
        obj_ = nedt.nedt()

        # copiando propriedades
        obj_.fog   = self.fog
        obj_.tiro  = self.tiro
        obj_.bdt   = self.bdt
        obj_.props = self.props
        obj_.teng  = self.teng
        
        return obj_

    def set_tiro0(self, tiro = None):
        if not tiro:
            tiro = self.tiro
        
        self.__tiro0 = tiro        
    
    def set_tiro_formosa(self):
        self.tiro = {
            'Elau': 261007.0,
            'Nlau': 8266712.0,
            'Alt_launch': 1004.0,
            'Latitude': 5.0,
            'Alt_met': 971.0,
            'Altfg': 971.0,
            'Etarg': 263769.0,
            'Ntarg': 8246846.0,
            'Altarg': 971.0,
            'T0': 24.6,
            'Proptemp': 24.6,
            'P0': 904.3,
            'Vws': 5.0,
            'Azws': 3028.0,
            'Metcm_included': 1,
            'Natm': 19,
            'Vwmetcm': [4.0, 7.0, 15.0, 21.0, 16.0, 11.0, 10.0, 12.0, 12.0, 13.0, 14.0, 14.0, 22.0, 30.0, 28.0, 45.0, 54.0, 57.0, 62.0, 68.0],
            'Azwmetcm': [6370.0, 6250.0, 6340.0, 570.0, 700.0, 890.0, 1370.0, 1750.0, 2310.0, 2710.0, 2860.0, 3530.0, 3390.0, 2990.0, 2840.0, 2660.0, 2600.0, 2480.0, 2590.0, 2710.0],
            'Tent': [298.5, 296.6, 294.9, 293.4, 289.8, 286.1, 283.5, 280.1, 277.4, 274.0, 270.7, 267.9, 264.0, 258.6, 251.6, 245.9, 238.7, 230.0, 221.2, 212.3],
            'Pent': [905.0, 895.0, 869.0, 830.0, 782.0, 737.0, 694.0, 654.0, 615.0, 578.0, 543.0, 509.0, 462.0, 406.0, 355.0, 309.0, 269.0, 232.0, 200.0, 171.0],
            'Vweth': 0.0, 'Vwnth': 0.0, 'Vweff': 0.0, 'Vwnff': 0.0, 'RefDir': 0.0,
        }
        
        # gravando tiro0 na configuracao nova
        self.set_tiro0()

    def get_teng0(self):
        return self.__teng0

    def engine_load(self):
        res = nedt_engine.engine_load()
        if res:
            self.__model = res
        return res
    
    def engine_unload(self):
        res = nedt_engine.engine_unload(self.__model)
        if res:
            self.__model = 0
        return res

    @property
    def teng_th(self):
        self.__teng_th = self.teng['Thrust_fac']
        return self.__teng_th

    @teng_th.setter
    def teng_th(self, value):
        self.__teng_th = value
        self.teng = {'Thrust_fac': value}
    
    @property
    def teng_cd(self):
        self.__teng_cd = self.teng['Cd_fac']
        return self.__teng_cd

    @teng_cd.setter
    def teng_cd(self, value):
        self.__teng_cd = value
        self.teng = {'Cd_fac': value}

    @property
    def model(self):
        return self.__model

    @property
    def used_list(self):
        return self.__used_list

    @property
    def fog(self):
        return self.__fog
    
    @fog.setter
    def fog(self, fog):
        fog_ = fog.upper()
        fog_ = re.sub(r'(SS).*(\d\dG?)$',r'\1_\2',fog_)
        self.__fog = fog_
        if not nedt_engine.config_edt(self.__model, fog_):
            print(f'\nERRO AO CONFIGURAR FOGUETE \'{fog_}\'\n')
            self.__fog = '--'

    @property
    def fuze(self):
        return self.get_data('nedt/Fusetime')

    @fuze.setter
    def fuze(self, value):
        self.__fuze = value
        self.set_data('Fusetime_input', value)

    @property
    def elev(self):
        self.__elev = self.get_data('Elev_tiro')
        return self.__elev

    @elev.setter
    def elev(self, value):
        self.__elev = value
        self.set_data('Elev_tiro', value)

    @property
    def azi(self):
        self.__azi = self.get_data('Azim_tiro')
        return self.__azi

    @azi.setter
    def azi(self, value):
        self.__azi = value
        self.set_data('Azim_tiro', value)

    @property
    def err(self):
        return self.__err

    @property
    def rec(self):
        self.__rec = self.get_data('nedt/rec_flag')
        return self.__rec
    
    @rec.setter
    def rec(self, value):
        self.set_data('nedt/rec_flag', value)
    
    @property
    def secb(self):
        self.__secb = self.get_data('Sec_bal')
        return self.__secb
    
    @secb.setter
    def secb(self, value):
        self.set_data('Sec_bal', value)
    
    @property
    def met(self):
        self.__met = self.tiro['Metcm_included']
        return self.__met
    
    @met.setter
    def met(self, value):
        self.tiro = {'Metcm_included': value}
    
    @property
    def met_natm(self):
        self.__met_natm = self.tiro['Natm']
        return self.__met_natm
    
    @met_natm.setter
    def met_natm(self, value):
        self.tiro = {'Natm': value}
    
    @property
    def vsup_vel(self):
        self.__vsup_vel = self.tiro['Vws']
        return self.__vsup_vel
    
    @vsup_vel.setter
    def vsup_vel(self, value):
        self.tiro = {'Vws': value}
    
    @property
    def vsup_azi(self):
        self.__vsup_azi = self.tiro['Azws']
        return self.__vsup_azi
    
    @vsup_azi.setter
    def vsup_azi(self, value):
        self.tiro = {'Azws': value}
    
    @property
    def temp(self):
        self.__temp = self.tiro['T0']
        return self.__temp
    
    @temp.setter
    def temp(self, value):
        self.tiro = {'T0': value}
    
    @property
    def pressao(self):
        self.__pressao = self.tiro['P0']
        return self.__pressao
    
    @pressao.setter
    def pressao(self, value):
        self.tiro = {'P0': value}
    
    @property
    def proptemp(self):
        self.__proptemp = self.tiro['Proptemp']
        return self.__proptemp
    
    @proptemp.setter
    def proptemp(self, value):
        self.tiro = {'Proptemp': value}
    
    @property
    def bdt_emin(self):
        self.__bdt_emin = self.bdt['Elev_min']
        return self.__bdt_emin
    
    @bdt_emin.setter
    def bdt_emin(self, value):
        self.bdt = {'Elev_min': value}

    @property
    def bdt_emax(self):
        self.__bdt_emax = self.bdt['Elevmax']/.05625
        return self.__bdt_emax
    
    @bdt_emax.setter
    def bdt_emax(self, value):
        self.bdt = {'Elevmax': value*.05625}
    
    @property
    def bdt_mass(self):
        self.__bdt_mass = self.bdt['Mass']
        return self.__bdt_mass
    
    @bdt_mass.setter
    def bdt_mass(self, value):
        self.bdt = {'Mass': value}
    
    @property
    def met_vel(self):
        self.__met_vel = self.tiro['Vwmetcm']
        return self.__met_vel
    
    @met_vel.setter
    def met_vel(self, value):
        self.tiro = {'Vwmetcm': value}

    @property
    def met_azi(self):
        self.__met_azi = self.tiro['Azwmetcm']
        return self.__met_azi
    
    @met_azi.setter
    def met_azi(self, value):
        self.tiro = {'Azwmetcm': value}

    @property
    def met_temp(self):
        self.__met_temp = self.tiro['Tent']
        return self.__met_temp
    
    @met_temp.setter
    def met_temp(self, value):
        self.tiro = {'Tent': value}

    @property
    def met_press(self):
        self.__met_press = self.tiro['Pent']
        return self.__met_press
    
    @met_press.setter
    def met_press(self, value):
        self.tiro = {'Pent': value}
    
    @property
    def met_h(self):
        self.__met_h = self.tiro['Alt_met']
        return self.__met_h
    
    @met_h.setter
    def met_h(self, value):
        self.tiro = {'Alt_met': value}
    
    @property
    def fg_h(self):
        self.__fg_h = self.tiro['Altfg']
        return self.__fg_h
    
    @fg_h.setter
    def fg_h(self, value):
        self.tiro = {'Altfg': value}
    
    @property
    def lmu(self):
        self.__lmu = self.get_lmu()
        return self.__lmu
    
    @lmu.setter
    def lmu(self, value):
        self.set_data('Elau', value[0])
        self.set_data('Nlau', value[1])
        
        if len(value) == 3:
            self.set_data('Alt_launch', value[2])
            
            # teste diferenca 'Altfg' e 'Alt_met'
            dif = abs(self.tiro['Altfg'] - value[2])
            if (dif > 50.):
                print(f"Altfg: {self.tiro['Altfg']:.1f} m (dif. lmu: {dif:.1f} m)")
            
            dif = abs(self.tiro['Alt_met'] - value[2])
            if (dif > 50.):
                print(f"Alt_met: {self.tiro['Alt_met']:.1f} m (dif. lmu: {dif:.1f} m)")

    
    @property
    def alvo(self):
        self.__alvo = self.get_alvo()
        return self.__alvo
    
    @alvo.setter
    def alvo(self, value):
        self.set_data('Etarg', value[0])
        self.set_data('Ntarg', value[1])
        
        if len(value) == 3:
            self.set_data('Altarg', value[2])

    # PARAMETROS DE TIRO
    @property
    def tiro(self):
        self.__tiro = self.get_tiro()
        return self.__tiro
    
    @tiro.setter
    def tiro(self, value):
        for v in value:
            self.set_data(v, value[v])

    # PARAMETROS DO OBJETO novaEdt
    @property
    def props(self):
        self.__props = self.get_props()
        return self.__props
    
    @props.setter
    def props(self, value):
        for v in value:
            self.set_data(f'nedt/{v}', value[v])

    # BDT
    @property
    def bdt(self):
        self.__bdt = self.get_bdt()
        return self.__bdt
    
    @bdt.setter
    def bdt(self, value):
        for v in value:
            self.set_data('bdt/{}'.format(v), value[v])

    # TELA DE ENGENHARIA
    @property
    def teng(self):
        self.__teng = self.get_tela_eng()
        return self.__teng
    
    @teng.setter
    def teng(self, value):
        for v in value:
            self.set_data('teng/{}'.format(v),value[v])
    
    # DADOS DE RASTREIO
    @property
    def trackdata(self):
        return self.__trackdata
    
    @trackdata.setter
    def trackdata(self, value):
        self.__trackdata = value
    
    @property
    def trackconfig(self):
        return self.__trackconfig
    
    @trackconfig.setter
    def trackconfig(self, value):
        self.__trackconfig = value

    # ponto de impacto
    @property
    def impacto(self):
        self.__impacto = self.get_impacto()
        return self.__impacto
    
    @impacto.setter
    def impacto(self, value):
        self.set_data('nedt/posicaoImpacto', value)

    def access_data(self, name, alias = ''):
        if alias == '':
            alias = name

        value = nedt_engine.get_data(self.__model, name)
        data  = ModelData(self.__model, name, value, alias)

        self.__used_list[name] = alias

        self.__dict__[alias] = data
    
    def set_vento_estimado(self, vento):        
        for v in vento:
            self.set_data(v,vento[v])            

    def calcular_tiro(self):
        erro = nedt_engine.calcular_tiro(self.__model)
        self.__err = erro
    
    def calcular_tiro_round(self):
        erro = nedt_engine.calcular_tiro_round(self.__model)
        self.__err = erro
    
    def calcular_tiro_dx(self, dx):
        erro = nedt_engine.calcular_tiro_dx(self.__model, dx)
        self.__err = erro
    
    def calcular_ventoth(self):
        erro = nedt_engine.calcular_ventoth(self.__model)
        self.__err = erro
    
    def calcular_ventoff(self):
        erro = nedt_engine.calcular_ventoff(self.__model)
        self.__err = erro
        return (self.props['Vweff'], self.props['Vwnff'])
    
    def reset_estimativa_ventos(self):
        # zerando estimativas de vento das propriedades
        self.props = {
            'Vweth': 0.,
            'Vwnth': 0.,
            'Vweff': 0.,
            'Vwnff': 0.,    
        }

        # zerando estimativas de vento do `edtData`
        self.tiro = {
            'Vweth': 0.,
            'Vwnth': 0.,
            'Vweff': 0.,
            'Vwnff': 0.,    
        }
    
    def calcular_correcao_de_vento(self):
        # FIXME: esse metodo aparenta deixar a correcao muito restrita, vide `ASTROS\20JUL_C35\python\py_ajuste_vento`
                
        # calculando pontos pelos dados do rastreio
        ci = self.get_tratar_dados_legacy()

        # lendo impacto arquivo de rastreio
        impacto = [self.trackconfig.get('impacto_este')[0], self.trackconfig.get('impacto_norte')[0]]

        # escrevendo no objeto
        self.props = {
            'posicaoFimDeQueima': ci['C0_fq'][1:4],
            'velocidadeFimDeQueima': ci['C0_fq'][4:],
            'posicaoFimDeVoo': impacto
        }

        # zerando estimativas de vento
        self.reset_estimativa_ventos()

        # calculando ventos
        self.calcular_ventoth()
        self.calcular_ventoff()

    def get_ss40g_dx(self):
        dx = nedt_engine.get_ss40g_dx(self.__model)
        return dx
    
    def get_tempo_he(self):
        tempo = nedt_engine.get_tempo_he(self.__model)
        return tempo

    def calcular_tiro_ss40g(self):
        erro = nedt_engine.calcular_tiro_ss40g(self.__model)
        self.__err = erro

    def get_atmosisa(self, alt):
        T, P, vsom, rho = nedt_utils.atmosisa(alt)
        res = {
            'T': T,
            'T_celcius': T-273.15,
            'P': P,
            'P_mbar': P/100.,
            'vsom': vsom,
            'rho': rho,
        }

        return res
        

    def set_atmosisa(self, alt):
        # calculando valor de temperatura e pressao ATMOSISA
        T, P, _, _ = nedt_utils.atmosisa(alt)
        
        # convertendo para graus Celcius
        T = T - 273.15

        # convertendo para mBar
        P = P / 100.0
        
        # escrevendo valores
        self.tiro = {
            'T0': T,
            'Proptemp': T,
            'P0': P,
            'Alt_launch': alt,
            'Altarg': alt,
            'Alt_met': alt,
            'Altfg': alt,
        }
    
    def get_alcance(self):
        return nedt_engine.get_alcance(self.__model)
    
    def get_alcance_min(self):
        return nedt_engine.get_alcance_minimo(self.__model)
    
    def get_alcance_max(self):
        return nedt_engine.get_alcance_maximo(self.__model)
    
    def get_alcance_max_azi(self, azi0 = 0.):
        return nedt_engine.get_alcance_maximo_azi(self.__model, azi0)

    def get_alcance_max_brute(self, verbose=0):
        # salvando elevacao inicial
        elev_ = self.elev        
        
        amax = 0.
        emax = 0.
        cont = 0
        for e in np.arange(np.floor(self.bdt_emax), 1400., 0.5):
            self.elev = e
            self.voar_completo()
            alc = self.get_dist_impacto()
            
            if verbose:
                print(f'elev: {e:.1f} mils, alc: {alc:.2f} m', end='')

            if amax < alc:
                amax = alc
                emax = e
                cont = 0
                if verbose:
                    print(' ...')
            else:
                cont += 1
                if verbose:
                    print('')
            
            # se alcance max nao atualizar por 5 iter, terminar
            if cont > 5:
                break

        if verbose:
            print('--------------------------------------')
            print(f'elev max: {emax:.1f} mils, alc max: {amax:.2f} m')
    
        # restaurando elevacao inicial
        self.elev = elev_

        return (amax, emax)
                
    def get_range(self):
        mi = self.get_alcance_min()[0]
        ma = self.get_alcance_max()[0]
        return (mi,ma)

    def get_error(self):
        #define BALISTIC_ERROR001 1 //ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DO ALVO
        #define BALISTIC_ERROR002 2 //ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DE EJECAO
        #define BALISTIC_ERROR003 3 //ALVO MUITO CURTO
        #define BALISTIC_ERROR004 4 //ALVO MUITO LONGO

        error = self.__err

        err_txt = 'nao ha erros!'
        
        if error == 1:
            err_txt = 'ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DO ALVO!'
        if error == 2:
            err_txt = 'ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DE EJECAO!'
        if error == 3:
            err_txt = 'ALVO MUITO CURTO!'
        if error == 4:
            err_txt = 'ALVO MUITO LONGO!'

        return err_txt

    def get_data(self, name):
        if self.__model:
            res = nedt_engine.get_data(self.__model, name)
        else: 
            res = 0
        return res
    
    def set_data(self, name, value):
        if self.__model:
            if np.isscalar(value):
                res = nedt_engine.set_data(self.__model, name, value)
            else: 
                res = nedt_engine.set_data(self.__model, name, [v for v in value])
        else: 
            res = 0
        return res
    
    def get_voo_ejec(self):
        v = self.get_voo()
        
        # filtrando valores em 'fuze'
        e = v[v.t >= self.fuze][0:1]

        return e

    def get_hejec(self):
        return self.get_data('nedt/Hejec')

    def get_ejecao(self):
        
        if self.secb == 0:
            return (-1, -1)
        
        v = self.get_voo()
        v = v[v.t<=self.fuze]

        return (v.alc.values[-1], v.h.values[-1])

    def get_hejec(self):
        v = self.get_voo()
        idif = v.vtot.diff().idxmin() - 2

        h = v.h[idif]
        return h

    def get_dgt(self):
        alvo = self.get_alvo()
        lmu  = self.get_lmu()

        v1   = [0., 1.]
        v    = np.subtract(alvo,lmu)[0:2]

        azi  = np.arccos(np.dot(v,v1)/np.linalg.norm(v)/np.linalg.norm(v1)) * 3200. / np.pi
        sig  = np.cross([*v, 0.], [*v1, 0.])[2]

        if sig < 0.0:
            azi = 6400.0 - azi

        return azi

    def get_metcm(self):
        vel   = self.tiro['Vwmetcm']
        azi   = self.tiro['Azwmetcm']
        temp  = self.tiro['Tent']
        press = self.tiro['Pent']
        natm  = self.tiro['Natm']    
        
        D = pd.DataFrame(np.column_stack([vel, azi, temp, press]), columns=['vel', 'azi', 'temp', 'press'])
        D = D[0:natm+1]
        return D

    def get_dist_alvo(self):
        lmu  = self.get_lmu()
        alvo = self.get_alvo()
        return np.linalg.norm(np.subtract(lmu, alvo)[0:2])
    
    def get_dist_impacto(self):
        lmu     = self.get_lmu()
        impacto = self.get_impacto()
        return np.linalg.norm(np.subtract(lmu, impacto)[0:2])

    def get_dist_impacto_track(self):
        lmu     = self.get_lmu()
        impacto = self.get_impacto_track()
        return np.linalg.norm(np.subtract(lmu[0:2], impacto))
    
    def get_impacto(self):
            value = [*self.get_data('nedt/posicaoImpacto')]
            return value
        
    def get_impacto_track(self):
            e = self.trackconfig.get('impacto_este')[0]
            n = self.trackconfig.get('impacto_norte')[0]
            return (e,n)
        
    def get_fim_de_queima_track(self):
            x = self.trackconfig.get('fim_de_queima_x')[0]
            y = self.trackconfig.get('fim_de_queima_y')[0]
            z = self.trackconfig.get('fim_de_queima_z')[0]
            return (x, y, z)

    def get_extrap_track(self):
            x = self.trackconfig.get('extrapolacao_x')[0]
            y = self.trackconfig.get('extrapolacao_y')[0]
            z = self.trackconfig.get('extrapolacao_z')[0]
            return (x, y, z)        
    
    def get_desvios_track(self):
            dalc = self.trackconfig.get('desvio_em_alcance')[0]
            dlat = self.trackconfig.get('desvio_lateral')[0]

            desvios = {
                'alc': dalc,
                'lat': dlat
            }

            return desvios
        
    def get_apogeu(self):
        return self.get_data('nedt/apogeu')

    def get_apogeu_range(self):
        return self.get_data('nedt/range_apogeu')
    
    def get_lmu(self):
        e = self.get_data('Elau')
        n = self.get_data('Nlau')
        h = self.get_data('Alt_launch')

        return (e,n,h)
    
    def set_altitude_fog(self, value): 
        self.tiro = {
            'Altfg': value,
            'Alt_met': value,
            'Alt_launch':  value,
            'Altarg':  value,
        }

    def get_alvo(self, lmu = None, dist = -1.0, azi = -1.0):

        # devolver alvo do modelo
        if dist < 0.0:
            e = self.get_data('Etarg')
            n = self.get_data('Ntarg')
            h = self.get_data('Altarg')
            return (e,n,h)
        
        # calcular novo alvo
        if not lmu:
            lmu = self.get_lmu()
        
        if azi < 0.0:
            azi = self.get_dgt()

        v  = [0.0, dist]
        
        ang = azi * np.pi / 3200.0
        vv  = [v[0] * np.cos(ang) + v[1] * np.sin(ang), -v[0] * np.sin(ang) + v[1] * np.cos(ang), ]

        alvo = [lmu[0] + vv[0], lmu[1] + vv[1]]
        alvo = [np.round(a*10.0)/10.0 for a in alvo]

        return alvo
    
    def set_alvo(self, alvo = None, dist = -1.0, azi = -1.0, lmu = None):

        # escrever alvo input
        if alvo:
            self.alvo = alvo
            return self.alvo
        
        # escrever alvo calculado
        if not lmu:
            lmu = self.lmu
        
        if azi < 0.0:
            azi = self.get_dgt()


        alvo = self.get_alvo(lmu=lmu, dist=dist, azi=azi)
        
        self.alvo = alvo
        return self.alvo

    
    def get_desvios(self):
        
        return nedt_engine.get_desvios(self.__model)
    
    def get_tiro(self):
        tiro = {}

        # LANCADORA
        tiro['Elau'] = self.get_data('Elau')
        tiro['Nlau'] = self.get_data('Nlau')
        tiro['Alt_launch'] = self.get_data('Alt_launch')
        tiro['Latitude'] = self.get_data('Latitude')
        tiro['Alt_met'] = self.get_data('Alt_met')
        tiro['Altfg'] = self.get_data('Altfg')

        # ALVO
        tiro['Etarg'] = self.get_data('Etarg')
        tiro['Ntarg'] = self.get_data('Ntarg')
        tiro['Altarg'] = self.get_data('Altarg')

        # CONDICOES DE AMBIENTE PADRAO
        tiro['T0'] = self.get_data('T0')
        tiro['Proptemp'] = self.get_data('Proptemp')
        tiro['P0'] = self.get_data('P0')

        # VENTO SUP
        tiro['Vws'] = self.get_data('Vws')
        tiro['Azws'] = self.get_data('Azws')

        # METCM
        tiro['Metcm_included'] = self.get_data('Metcm_included')
        tiro['Natm'] = self.get_data('Natm')
        tiro['Vwmetcm'] = self.get_data('Vwmetcm')
        tiro['Azwmetcm'] = self.get_data('Azwmetcm')
        tiro['Tent'] = self.get_data('Tent')
        tiro['Pent'] = self.get_data('Pent')

        # ELEMENTOS DE TIRO
        tiro['Elev_tiro'] = self.get_data('Elev_tiro')
        tiro['Azim_tiro'] = self.get_data('Azim_tiro')
        tiro['Fusetime_input'] = self.get_data('Fusetime_input')
        tiro['Sec_bal'] = self.get_data('Sec_bal')

        # VENTOS ESTIMADOS
        tiro['Vweth'] = self.get_data('Vweth')
        tiro['Vwnth'] = self.get_data('Vwnth')
        tiro['Vweff'] = self.get_data('Vweff')
        tiro['Vwnff'] = self.get_data('Vwnff')

        tiro['RefDir'] = self.get_data('RefDir')

        return tiro

    def get_props(self):
        ''' get_props: le valores de propriedade do objeto `novaEdt`
        '''

        props = {}
        props['tempoQueima']           = self.get_data('nedt/tempoQueima')
        props['tempoFimSimulacao']     = self.get_data('nedt/tempoFimSimulacao')
        props['posicaoFimDeQueima']    = [v for v in self.get_data('nedt/posicaoFimDeQueima')]
        props['velocidadeFimDeQueima'] = [v for v in self.get_data('nedt/velocidadeFimDeQueima')]
        props['posicaoFimDeVoo']       = [v for v in self.get_data('nedt/posicaoFimDeVoo')]
        props['posicaoImpacto']        = [v for v in self.get_data('nedt/posicaoImpacto')]
        props['pontoObservado']        = [v for v in self.get_data('nedt/pontoObservado')]
        props['rangeMin']              = self.get_data('nedt/rangeMin')
        props['rangeMax']              = self.get_data('nedt/rangeMax')
        props['elevMin']               = self.get_data('nedt/elevMin')
        props['elevMax']               = self.get_data('nedt/elevMax')
        props['janelaExtrapT0']        = self.get_data('nedt/janelaExtrapT0')
        props['janelaExtrapTf']        = self.get_data('nedt/janelaExtrapTf')
        props['Hejec']                 = self.get_data('nedt/Hejec')
        props['Fusetime']              = self.get_data('nedt/Fusetime')
        props['FlagEjec']              = self.get_data('nedt/FlagEjec')
        props['Tejec']                 = self.get_data('nedt/Tejec')
        props['apogeu']                = self.get_data('nedt/apogeu')
        props['range_apogeu']          = self.get_data('nedt/range_apogeu')
        props['Vweth']                 = self.get_data('nedt/Vweth')
        props['Vwnth']                 = self.get_data('nedt/Vwnth')
        props['Vweff']                 = self.get_data('nedt/Vweff')
        props['Vwnff']                 = self.get_data('nedt/Vwnff')

        return props

    # set_apogeu: ajusta elevacao do foguete ateh encontrar o valor de 
    #             apogeu de 'href'
    def set_apogeu(self, href):
        
        a = self.bdt['Elev_min']
        b = self.bdt['Elev_tat']*2.0
        
        for _ in range(20):
            # gerando nova condicao de tiro
            x   = (a + b) / 2.
            
            # calculo do voo
            self.elev = x
            
            # calculo do erro
            h   = self.get_voo().z.max()
            err = h - href
    
            # condicao de fim de busca    
            if abs(err) < 1.0:
                break
            
            # atualizacao dos limites
            if err < 0.0:
                a = x
            else:
                b = x
    
    def set_apogeu_radar(self):
        self.set_apogeu(self.get_radar().h.max())

    # set_hejec: ajusta elevacao do foguete ateh encontrar o valor de 
    #             elevacao de ejecao de 'href'
    def set_hejec(self, href):
        
        a = self.bdt['Elev_min']
        b = self.bdt['Elev_tat']*2.0
        
        for _ in range(20):
            # gerando nova condicao de tiro
            x   = (a + b) / 2.
            
            # calculo do voo
            self.elev = x
            
            # calculo do erro
            
            e   = self.get_voo_ejec() 
            
            if len(e):
                h   = e.h.values[0]
                err = h - href
            else:
                a = x
                continue
    
            # condicao de fim de busca    
            if abs(err) < 1.0:
                break
            
            # atualizacao dos limites
            if err < 0.0:
                a = x
            else:
                b = x

    def resultados(self, hard = 0):
                       
        # gerando txt error
        error_txt = self.get_error()
        
        # calculando alcances
        mi = self.get_alcance_min()[0]
        ma = self.get_alcance_max()[0]
        
        tiro = self.tiro
                
        alcance = np.hypot(tiro['Elau'] - tiro['Etarg'], tiro['Nlau'] - tiro['Ntarg'])

        # TODO: colocar distancia alvo +1 elev e -1 elev
        # imprimindo resultados
        barra = '---------------------------------------------------'
        print(barra)
        print(f'fog......[nome]: {self.fog}')
        print(f'alc. alvo...[m]: {alcance:.1f}')
        print(barra)
        print(f'erros.....[str]: {error_txt}')
        print(barra)
        
        temp  = tiro['T0']
        press = tiro['P0']

        if (not self.err) or (hard == 1):
            desvios = self.get_desvios()

            print(f'elevacao.[mils]: {self.get_data("Elev_tiro"):.1f}')
            print(f'azimute..[mils]: {self.get_data("Azim_tiro"):.1f}')
            print(f'fuze......[seg]: {self.fuze:.1f}')
            print(f'alcance.....[m]: {self.get_alcance():.1f}')
            print(f'flecha......[m]: {self.get_apogeu():.1f}')
            print(f'desv. alc...[m]: {desvios["alc"]:.1f}')
            print(f'desv. lat...[m]: {desvios["lat"]:.1f}')
            print(f'secbal..[0|1|2]: {self.get_data("Sec_bal"):d}')
            print(barra)
            print(f'alt.  lmu...[m]: {self.lmu[2]:.1f}')
            print(f'range.......[m]: ({mi:.1f}, {ma:.1f})')
            print(f'dgt......[mils]: {self.get_dgt():.1f}')
            print(barra)
            print(f'temp..[celcius]: {temp:.1f}')
            print(f'press....[mBar]: {press:.1f}')
            print(barra)
    
    def resultados_impacto(self):
        elev  = self.get_data('Elev_tiro')
        etarg = self.get_data('Etarg')
        ntarg = self.get_data('Ntarg')
        
        impacto = self.get_impacto()
        diff    = np.subtract(impacto[:2], [etarg, ntarg])
        print('')
        print('elev   : {:.2f}'.format(elev))
        print('alvo   : {:8.1f}, {:8.1f}'.format(etarg, ntarg))
        print('impacto: {:8.1f}, {:8.1f}'.format(impacto[0], impacto[1]))
        print('diff   : {:8.1f}, {:8.1f}'.format(diff[0], diff[1]))

    def resultados_cpp(self):
        print('RESULTADOS:')
        T = self.tiro
        
        impacto = self.get_impacto()
        alvo    = self.get_alvo()

        print('Elev: {:.2f}   Azi:   {:.2f}   Secbal: {}'.format(T['Elev_tiro'], T['Azim_tiro'], T['Sec_bal']))
        print('FimDeVoo          : [ 0.0  0.0  0.0 ]')
        print('Impacto           : [ {:.2f}  {:.2f}  {:.2f} ]'.format(*impacto))
        print('Alvo              : [ {:.2f}  {:.2f}  {:.2f} ]'.format(*alvo))
        print('Impacto - Alvo    : [ {:.2f}  {:.2f}  {:.2f} ]'.format(*np.subtract(impacto,alvo)))
        print('Apogeu            : {:.2f}'.format(self.get_apogeu()))
        print('Alcance           : {:.2f}'.format(self.get_alcance()))
        print('Desvio Alcance    : {:.2f}'.format(self.get_desvios()[0]))
        print('Desvio Lateral    : {:.2f}'.format(self.get_desvios()[1]))
        print('Valor de fuzetime : {:.2f}'.format(self.fuze))
        print('Valor de hejec    : {:.2f}'.format(self.get_hejec()))
    
    def get_tela_eng(self):
        tela = {
            'Delta_x':    self.get_data('teng/Delta_x'),
            'Delta_y':    self.get_data('teng/Delta_y'),
            'Delta_z':    self.get_data('teng/Delta_z'),
            'Delta_vx':   self.get_data('teng/Delta_vx'),
            'Delta_vy':   self.get_data('teng/Delta_vy'),
            'Delta_vz':   self.get_data('teng/Delta_vz'),
            'Cd_fac':     self.get_data('teng/Cd_fac'),
            'Cdsm_fac':   self.get_data('teng/Cdsm_fac'),
            'Thrust_fac': self.get_data('teng/Thrust_fac'),
            'Tubetime':   self.get_data('teng/Tubetime'),
            'Delta_ejec': self.get_data('teng/Delta_ejec'),
            'Mass':       self.get_data('teng/Mass'),
            'Propmass':   self.get_data('teng/Propmass'),
            'Hejec':      self.get_data('teng/Hejec')
        }

        return tela

    def get_bdt(self):
        bdt = {
            'Mass': self.get_data('bdt/Mass'),
            'Propmass': self.get_data('bdt/Propmass'),
            'Laul': self.get_data('bdt/Laul'),
            'Diaref': self.get_data('bdt/Diaref'),
            'N_points': self.get_data('bdt/N_points'),
            'Ass': self.get_data('bdt/Ass'),
            'Pnom': self.get_data('bdt/Pnom'),
            'Emp': self.get_data('bdt/Emp'),
            'Elevmax': self.get_data('bdt/Elevmax'),
            'Elev_tat': self.get_data('bdt/Elev_tat'),
            'Elev_min': self.get_data('bdt/Elev_min'),
            'Vwmax': self.get_data('bdt/Vwmax'),
            'Cdadj': self.get_data('bdt/Cdadj'),
            'Cdadjsm': self.get_data('bdt/Cdadjsm'),
            'Fpon': self.get_data('bdt/Fpon'),
            'T_emp_step': self.get_data('bdt/T_emp_step'),
            'P_emp_tp_1': self.get_data('bdt/P_emp_tp_1'),
            'P_emp_tp_2': self.get_data('bdt/P_emp_tp_2'),
            'P_emp_tp_3': self.get_data('bdt/P_emp_tp_3'),
            'P_emp_tp_4': self.get_data('bdt/P_emp_tp_4'),
            'P_emp_tp_5': self.get_data('bdt/P_emp_tp_5'),
            'V0_el': self.get_data('bdt/V0_el'),
            'V0_tp': self.get_data('bdt/V0_tp'),
            'T0_el': self.get_data('bdt/T0_el'),
            'T0_tp': self.get_data('bdt/T0_tp'),
            'Hejec1': self.get_data('bdt/Hejec1'),
            'Hejec2': self.get_data('bdt/Hejec2'),
            'Delta_ejec': self.get_data('bdt/Delta_ejec'),
            'Bwiwe': self.get_data('bdt/Bwiwe'),
            'Hmthph': self.get_data('bdt/Hmthph'),
            'Cwss': self.get_data('bdt/Cwss'),
            'Elcor_1': self.get_data('bdt/Elcor_1'),
            'Elcor_2': self.get_data('bdt/Elcor_2'),
            'Elcor_3': self.get_data('bdt/Elcor_3'),
            'Azcor_1': self.get_data('bdt/Azcor_1'),
            'Azcor_2': self.get_data('bdt/Azcor_2'),
            'Azcor_3': self.get_data('bdt/Azcor_3'),
            'Velcor_1': self.get_data('bdt/Velcor_1'),
            'Velcor_2': self.get_data('bdt/Velcor_2'),
            'Velcor_3': self.get_data('bdt/Velcor_3'),
            'Elbas': self.get_data('bdt/Elbas'),
            'Azbas': self.get_data('bdt/Azbas'),
            'Velbas': self.get_data('bdt/Velbas'),
            'El_to': self.get_data('bdt/El_to'),
            'Fuzecor1': self.get_data('bdt/Fuzecor1'),
            'Fuzecor2': self.get_data('bdt/Fuzecor2'),
        }

        return bdt

    def save_traj_to_xls(self, addr = 'traj.xls'):
        v = self.get_voo()
        v.to_excel(addr)

    def save_met(self, addr = 'met.cm'):
        met = self.get_metcm()
        # TODO: entender os nros gerados na primeira linha
     
        with open(addr, 'w') as f:
            f.write(f'METCM5 999999 999999 999999\n')
            cam = 0
            for v, a, t, p in zip(met.vel, met.azi, met.temp, met.press):
                cam_ = f'{cam:02d}'
                a_   = f'{round(a/10):03d}'
                v_   = f'{round(v):03d}'
                t_   = f'{round(t*10):04d}'
                p_   = f'{round(p):04d}'
                cam += 1
                f.write(f'{cam_}{a_}{v_} {t_}{p_}\n')

    def save_bdt(self, addr = 'bla.c'): 
        from datetime import date

        today = date.today().strftime('%d %b %Y')
        bdt   = self.bdt
        with open(addr, 'w') as f:

            f.write(f'// BALISTICA \'{self.fog}\'\n')
            f.write(f'// DATA DE MONTAGEM: {today}\n')
            f.write('\n')
            
            f.write(f'// [KG] TOTAL ROCKET MASS\n')
            f.write(f'DDT.Mass       = {bdt.get("Mass"):.2f};\n')
            f.write(f'// [KG] PROPELLANT MASS\n')
            f.write(f'DDT.Propmass   = {bdt.get("Propmass"):.2f};\n')
            f.write(f'// [M] LAUNCHER LENGHT\n')
            f.write(f'DDT.Laul       = {bdt.get("Laul"):.2f};\n')
            f.write(f'// [M] REFERENCE DIAMETER OF ROCKET\n')
            f.write(f'DDT.Diaref     = {bdt.get("Diaref"):.4f};\n')
            f.write(f'// NUMBER OF POINTS IN THRUST PROFILE\n')
            f.write(f'DDT.N_points   = {bdt.get("N_points"):.0f};\n')
            f.write(f'// [M2] EXAUST AREA\n')
            f.write(f'DDT.Ass        = {bdt.get("Ass"):.6f};\n')
            f.write(f'// [N/M2] REFERENCE PRESSURE\n')
            f.write(f'DDT.Pnom       = {bdt.get("Pnom"):.2f};\n')
            f.write(f'// [N] REFERENCE THRUST * STEP\n')
            f.write(f'DDT.Emp        = {bdt.get("Emp"):.2f};\n')
            f.write(f'// [DEG] MAXIMUM ELEVATION\n')
            f.write(f'DDT.Elevmax    = {bdt.get("Elevmax"):.1f};\n')
            f.write(f'// [M/S] MAXIMUM WIND VELOCITY\n')
            f.write(f'DDT.Vwmax      = {bdt.get("Vwmax"):.2f};\n')
            f.write(f'// CORRECTION FACTOR FOR DRAG IN THRUSTPHASE\n')
            f.write(f'DDT.Cdadj      = {bdt.get("Cdadj"):.2f};\n')
            f.write(f'// CORRECTION FACTOR FOR DRAG IN SEC. BAL.\n')
            f.write(f'DDT.Cdadjsm    = {bdt.get("Cdadjsm"):.2f};\n')
            f.write(f'// WEIGHTING FACTOR\n')
            f.write(f'DDT.Fpon       = {bdt.get("Fpon"):.2f};\n')

            f.write('\n')
            f.write('// [s] TRHUST TIME (STEP) \n')
            for i in range(20):
                f.write(f'DDT.T_emp_step[{i+1:2d}] = {bdt.get("T_emp_step")[i]};\n')

            f.write('\n')
            f.write('// TRHUST DATA \n')
            for i in range(5):
                for j in range(20):
                    f.write(f'DDT.P_emp_tp[{i+1:1}][{j+1:2d}] = {bdt.get(f"P_emp_tp_{i+1}")[j]};\n')
                f.write('\n')
            
            f.write('// F(ELEV.)\n')
            for i in range(3):
                f.write(f'DDT.V0_el[{i+1:d}] = {bdt.get("V0_el")[i]};\n')
            
            f.write('\n')
            f.write('// F(PROP. TEMP.)\n')
            for i in range(3):
                f.write(f'DDT.V0_tp[{i+1:d}] = {bdt.get("V0_tp")[i]};\n')
            
            f.write('\n')
            f.write('// F(ELEV.)\n')
            for i in range(3):
                f.write(f'DDT.T0_el[{i+1:d}] = {bdt.get("T0_el")[i]};\n')
            
            f.write('\n')
            f.write('// F(PROP. TEMP.)\n')
            for i in range(3):
                f.write(f'DDT.T0_tp[{i+1:d}] = {bdt.get("T0_tp")[i]};\n')
            
            f.write('\n')
            f.write('// [M] HEIGHT OF EJECTION RELATIVE TO TARGET\n')
            for i in range(5):
                f.write(f'DDT.Hejec1[{i+1:d}] = {bdt.get("Hejec1")[i]};\n')
            
            f.write('\n')
            f.write('// [M] HEIGHT OF EJECTION RELATIVE TO TARGET\n')
            for i in range(5):
                f.write(f'DDT.Hejec2[{i+1:d}] = {bdt.get("Hejec2")[i]};\n')

            f.write('\n')
            f.write('// [SEC] DELAY OF EJECTION\n')
            f.write(f'DDT.Delta_ejec = {bdt.get("Delta_ejec"):.3f};\n')
                        
            f.write('\n')
            f.write('// WIND WEIGHTING POLYNOM\n')
            for i in range(6):
                f.write(f'DDT.Bwiwe[{i+1:d}] = {bdt.get("Bwiwe")[i]};\n')
                        
            f.write('\n')
            f.write('// HEIGHT OF END OF THRUSTPHASE\n')
            for i in range(4):
                f.write(f'DDT.Hmthph[{i+1:d}] = {bdt.get("Hmthph")[i]};\n')
                        
            f.write('\n')
            f.write('// DRAG\n')
            for i in range(41):
                f.write(f'DDT.Cwss[{i:2d}] = {bdt.get("Cwss")[i]:.8f};\n')

            f.write('\n')
            f.write('// [MILS] MAX. TACTICAL ELEVATION\n')
            f.write(f'DDT.Elev_tat   = {bdt.get("Elev_tat"):.1f};\n')

            f.write('\n')
            f.write('// [MILS] MIN. TACTICAL ELEVATION\n')
            f.write(f'DDT.Elev_min   = {bdt.get("Elev_min"):.1f};\n')

            f.write('\n')
            f.write('// FLIGHT_TIME/ FUZE_TIME (low ejection)\n')
            for i in range(3):
                f.write(f'DDT.Fuzecor1[{i+1:d}] = {bdt.get("Fuzecor1")[i]};\n')

            f.write('\n')
            f.write('// FLIGHT_TIME/ FUZE_TIME (high ejection)\n')
            for i in range(3):
                f.write(f'DDT.Fuzecor2[{i+1:d}] = {bdt.get("Fuzecor2")[i]};\n')

            f.write('\n')
            f.write('// ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE\n')
            f.write('//       En^0          En^1          En^2\n')
            f.write('// VY^0*VX^0\n')
            f.write('// VY^1*VX^0\n')
            f.write('// VY^2*VX^0\n')
            f.write('// VY^0*VX^1\n')
            f.write('// VY^1*VX^1\n')
            f.write('// VY^2*VX^1\n')
            f.write('// VY^0*VX^2\n')
            f.write('// VY^1*VX^2\n')
            f.write('// VY^2*VX^2\n')

            for i in range(3):
                for j in range(9):
                    f.write(f'DDT.Elcor[{i+1:1}][{j+1:d}] = {bdt.get(f"Elcor_{i+1}")[j]:.8f};\n')
                f.write('\n')

            f.write('\n')
            f.write('// AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE\n')
            f.write('//       En^0          En^1          En^2\n')
            f.write('// VY^0*VX^0\n')
            f.write('// VY^1*VX^0\n')
            f.write('// VY^2*VX^0\n')
            f.write('// VY^0*VX^1\n')
            f.write('// VY^1*VX^1\n')
            f.write('// VY^2*VX^1\n')
            f.write('// VY^0*VX^2\n')
            f.write('// VY^1*VX^2\n')
            f.write('// VY^2*VX^2\n')

            for i in range(3):
                for j in range(9):
                    f.write(f'DDT.Azcor[{i+1:1}][{j+1:d}] = {bdt.get(f"Azcor_{i+1}")[j]:.8f};\n')
                f.write('\n')


            f.write('// DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE\n')
            f.write('//       En^0          En^1          En^2\n')
            f.write('// VY^0*VX^0\n')
            f.write('// VY^1*VX^0\n')
            f.write('// VY^2*VX^0\n')
            f.write('// VY^0*VX^1\n')
            f.write('// VY^1*VX^1\n')
            f.write('// VY^2*VX^1\n')
            f.write('// VY^0*VX^2\n')
            f.write('// VY^1*VX^2\n')
            f.write('// VY^2*VX^2\n')

            for i in range(3):
                for j in range(9):
                    f.write(f'DDT.Velcor[{i+1:1}][{j+1:d}] = {bdt.get(f"Velcor_{i+1}")[j]:.8f};\n')
                f.write('\n')

            # TODO: colocar legenda 'El_to' aqui
            f.write('// El to\n')
            f.write(f'DDT.El_to = {bdt.get("El_to"):.3f};\n')

            f.write('\n')
            # TODO: colocar legenda 'Elbas' aqui
            f.write('// Elbas\n')
            for i in range(3):
                f.write(f'DDT.Elbas[{i+1:d}] = {bdt.get("Elbas")[i]};\n')

            f.write('\n')
            # TODO: colocar legenda 'Azbas' aqui
            f.write('// Azbas\n')
            for i in range(3):
                f.write(f'DDT.Azbas[{i+1:d}] = {bdt.get("Azbas")[i]:e};\n')
            
            f.write('\n')
            # TODO: colocar legenda 'Velbas' aqui
            f.write('// Velbas\n')
            for i in range(3):
                f.write(f'DDT.Velbas[{i+1:d}] = {bdt.get("Velbas")[i]:e};\n')
        
    def load_bdt(self, addr = 'BDT40G.c'):
        # testando se `addr` existe
        import os

        addr_ = addr
        if not os.path.exists(addr_):
            addr_ = f'py/{addr_}'
            if not os.path.exists(addr_):
                print(f'endereco \'{addr}\' nao existe, abortando operacao!')
                return 0
            addr = addr_


        # pattern para ler valores escalares
        format_pat_scalar = re.compile(
            r"(?P<nome>DDT\.\w+)"
            r"([\s=\s]+)"
            r"(?P<valor>.+);"
        )
        
        # pattern para ler valores vetor de 1 dimensao
        format_pat_vector_1 = re.compile(
            r"(?P<nome>DDT\.\w+)"
            r"\[\s?(?P<pos>[\d\s]+)\]"
            r"([\s=\s]+)"
            r"(?P<valor>.+);"
        )
        
        # pattern para ler valores vetor de 2 dimensoes
        format_pat_vector_2 = re.compile(
            r"(?P<nome>DDT\.\w+)"
            r"\[\s?(?P<col>[\d\s]+)\]"
            r"\[\s?(?P<linha>[\d\s]+)\]"
            r"([\s=\s]+)"
            r"(?P<valor>.+);"
        )
        
        # lendo parametros BDT
        V_ = []
        
        with open(addr, 'r') as f:
            
            for line in f:
                
                # lendo valores de escalares
                match_scalar = format_pat_scalar.match(line)
                
                if match_scalar:
                    val = match_scalar.groupdict()
                    V_.append(val)
                    continue
                
                # lendo valores de vetores de 1 dimensao
                match_vector_1 = format_pat_vector_1.match(line)
                
                if match_vector_1:
                    val = match_vector_1.groupdict()
                    V_.append(val)
                    continue
                
                # lendo valores de vetores de 2 dimensao
                match_vector_2 = format_pat_vector_2.match(line)

                if match_vector_2:
                    val = match_vector_2.groupdict()
                    V_.append(val)
        
        # escrevendo parametros em forma de estrutura
        V = {}
        for v in V_:
            
            nome  = v['nome'].replace('DDT.', 'bdt/')
            valor = float(eval(re.sub(';//.+','',v['valor'])))
            
            # separando vetor 1 dimensao em vet_1
            if 'pos' in v:
                key = nome
                
                if key not in V:
                    V[key] = []
                
                V[key].append(valor)
                continue
        
            # separando vetor 2 dimensoes em vet_2
            if 'col' in v:
                col   = v['col']
                
                key   = f'{nome}_{col}'
                
                if key not in V:
                    V[key] = []

                V[key].append(valor)
                continue
        
            # separando escalares em scalar
            key   = nome
            V[key] = valor
                
        # escrevendo valores no objeto
        for v in V:
            self.set_data(v, V[v])
                
        return 1

    def get_config(self):
        
        # CONFIGURANDO FOGUETE
        fog  = self.fog
        tiro = self.get_tiro()

        # VENTOS ESTIMADOS
        vento_estimado = {}

        # vento_estimado['Vweth'] = num(r.config['ventoth_frontal'])
        # vento_estimado['Vwnth'] = num(r.config['ventoth_lateral'])
        # vento_estimado['Vweff'] = num(r.config['ventoff_frontal'])
        # vento_estimado['Vwnff'] = num(r.config['ventoff_lateral'])

        return fog, tiro, vento_estimado
    
    def get_config_from_file(self, addr):
        
        r = nedt_utils.ler_nedt(addr)
        
        self.trackconfig = r.config

        tiro = {}
        
        # CONFIGURANDO FOGUETE
        # nedt.fog = r.config['tipo_de_balistica']
        fog = r.config['tipo_de_balistica'][1]
        
        # CONDICOES DE AMBIENTE PADRAO
        # print(r.config['temperatura_do_ar'])
        tiro['T0']       = r.config['temperatura_do_ar'][0]
        tiro['Proptemp'] = r.config['temperatura_do_propelente'][0]
        tiro['P0']       = r.config['pressao_atmosferica'][0]
        
        # TIPO DE
        tiro['Sec_bal'] = r.config['balistica_secundaria'][0]

        # LANCADORA
        tiro['Elau'] = r.config['lancador_este'][0]
        tiro['Nlau'] = r.config['lancador_norte'][0]
        tiro['Alt_launch'] = r.config['lancador_altitude'][0]

        if 'latitude' in r.config.keys():
            tiro['Latitude'] = r.config['latitude'][0]
                
        # ALVO
        tiro['Etarg'] = r.config['alvo_este'][0]
        tiro['Ntarg'] = r.config['alvo_norte'][0]
        tiro['Altarg'] = r.config['alvo_altitude'][0]

        # VENTO
        if r.config['numero_da_ultima_camada_entrada'][0] > 0:
            tiro['Metcm_included'] = 1
        else:
            tiro['Metcm_included'] = 0

        tiro['Vws'] = r.config['velocidade_vento_superf'][0]
        tiro['Azws'] = r.config['azimute_vento_superf'][0]
        tiro['Alt_met'] = r.config['altitude_da_estacao_meteorologica'][0]
        tiro['Altfg'] = r.config['altitude_da_estacao_meteorologica'][0]
        tiro['Natm'] = r.config['numero_da_ultima_camada_entrada'][0]

        # CAMADAS DE VENTO
        tiro['Vwmetcm'] = [*r.config['metcm'].vel.values]
        tiro['Azwmetcm'] = [*r.config['metcm'].azi.values]
        tiro['Tent'] = [*r.config['metcm'].temp.values]
        tiro['Pent'] = [*r.config['metcm'].pres.values]

        # ELEMENTOS DE TIRO
        tiro['Elev_tiro'] = r.config['elevacao'][0]
        tiro['Azim_tiro'] = r.config['azimute'][0]
        tiro['Fusetime_input'] = r.config['tempo_escolhido'][0]
        
        # VENTOS ESTIMADOS
        tiro['Vweth'] = r.config['ventoth_frontal'][0]
        tiro['Vwnth'] = r.config['ventoth_lateral'][0]
        tiro['Vweff'] = r.config['ventoff_frontal'][0]
        tiro['Vwnff'] = r.config['ventoff_lateral'][0]

        vento_estimado = {}

        vento_estimado['Vweth'] = r.config['ventoth_frontal'][0]
        vento_estimado['Vwnth'] = r.config['ventoth_lateral'][0]
        vento_estimado['Vweff'] = r.config['ventoff_frontal'][0]
        vento_estimado['Vwnff'] = r.config['ventoff_lateral'][0]
        
        return fog, tiro, vento_estimado
    
    def reset_teng(self):
        nedt_engine.reset_tela_engenharia(self.__model)

    def reset_tiro(self):
        self.tiro = self.__tiro0
        self.props = {
            'Vweth': self.__tiro0['Vweth'],
            'Vwnth': self.__tiro0['Vwnth'],
            'Vweff': self.__tiro0['Vweff'],
            'Vwnff': self.__tiro0['Vwnff']
        }

    def voar_completo(self):
        # executando simulacao de voo completo
        erro = nedt_engine.voar_completo(self.__model)
        
        # retornando erro
        self.__err = erro

    def voar_completo_fuze(self):
        # executando simulacao de voo completo
        erro = nedt_engine.voar_completo_fuze(self.__model)
        
        # retornando erro
        self.__err = erro
    
    def voar_extrapolando(self, inicio):
        nedt_engine.voar_extrapolando(self.__model, inicio)
    
    def load_track_file(self, addr, silent=False):
        import os
        from glob import glob

        F = glob(f'{addr}\\*Resumo_Dados*.txt')
        
        if len(F) == 1:
            addr_ = F[0]
        else:
            addr_ = addr
            
        if not os.path.exists(addr_):
            
            addr_ = f'py/{addr_}'

            if not os.path.exists(addr_):
                print(f'endereco \'{addr}\' nao existe, abortando operacao!')
                return 0

        r   = nedt_utils.ler_nedt(addr_)
        nro = len(r.voo)
            
        fog, tiro, vento_estimado = self.get_config_from_file(addr_)
        if ('Elevacao' not in tiro) and (not silent):
            print('nao foi encontrado `Latitude`, usando valor padrao (5.0)')
        
        self.fog     = fog
        self.tiro    = tiro
        self.__tiro0 = tiro

        # inicializando impacto do arquivo de LOG
        # self.set_data('nedt/posicaoImpacto', self.get_impacto_track())

        self.set_vento_estimado(vento_estimado)
        self.trackdata = r.voo

        nedt_engine.init_from_file(self.__model, 'missionstate', r.voo['missionstate'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'positionstate', r.voo['positionstate'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'measured_pos_x', r.voo['measured_pos_x'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'measured_pos_y', r.voo['measured_pos_y'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'measured_pos_z', r.voo['measured_pos_z'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'one_sigma_x', r.voo['one_sigma_x'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'one_sigma_y', r.voo['one_sigma_y'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'one_sigma_z', r.voo['one_sigma_z'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'noise_ratio', r.voo['noise_ratio'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_pos_x', r.voo['filtered_pos_x'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_pos_y', r.voo['filtered_pos_y'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_pos_z', r.voo['filtered_pos_z'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_vel_x', r.voo['filtered_vel_x'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_vel_y', r.voo['filtered_vel_y'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'filtered_vel_z', r.voo['filtered_vel_z'].values[:nro])
        nedt_engine.init_from_file(self.__model, 'relative_time', r.voo['relative_time'].values[:nro])

        # calculando pontos pelos dados do rastreio
        ci = self.get_tratar_dados_legacy()

        # lendo impacto arquivo de rastreio
        impacto = [self.trackconfig.get('impacto_este')[0], self.trackconfig.get('impacto_norte')[0]]

        # escrevendo no objeto
        self.props = {
            'posicaoFimDeQueima': ci['C0_fq'][1:4],
            'velocidadeFimDeQueima': ci['C0_fq'][4:],
            'posicaoFimDeVoo': impacto
        }

        if not silent:
            print(f'(elev: {self.elev:.1f}, azi: {self.azi:.1f})')

        self.reset_teng()
    
    def load_track_file_antiga(self, addr):
        import os
        from glob import glob

        F = glob(f'{addr}\\*.lst')
        
        if len(F) == 1:
            addr_ = F[0]
        else:
            addr_ = addr
            
        if not os.path.exists(addr_):
            
            addr_ = f'py/{addr_}'

            if not os.path.exists(addr_):
                print(f'endereco \'{addr}\' nao existe, abortando operacao!')
                return 0

        D   = nedt_utils.ler_edt_antiga(addr_)
        # gravando rastreio
        r = D['radar']
                
        # tempo
        r['relative_time'] = r.time * 1000.
        
        # pos
        r['filtered_pos_x'] = r.x_a
        r['filtered_pos_y'] = r.y_a
        r['filtered_pos_z'] = r.z_a
        
        # vel
        r['filtered_vel_x'] = r.vx_a
        r['filtered_vel_y'] = r.vy_a
        r['filtered_vel_z'] = r.vz_a
        
        # covar
        r['one_sigma_x'] = np.zeros((len(r.vx_a), 1))
        r['one_sigma_y'] = np.zeros((len(r.vx_a), 1))
        r['one_sigma_z'] = np.zeros((len(r.vx_a), 1))

        self.trackdata = r
        
        # gravando configuracaoes de tiro
        c   = D['config']
        self.trackconfig = c
        tiro = {
            'Elau': c['E_Launcher'],
            'Nlau': c['N_Launcher'],
            'Etarg': c['E_Targuet'],
            'Ntarg': c['N_Targuet'],
            'Alt_launch': c['AltLaunch'],
            'Altarg': c['AltTarg'],
            'Latitude': c['Latitude'],
            'Alt_met': c['Altmet'],
            'Altfg': c['AltFG'],
            'T0': c['ArTemp'],
            'Proptemp': c['PropTemp'],
            'P0': c['Pressao'],
            'Vws': c['Vws'],
            'Azws': c['Azws'],
            'Metcm_included': c['METCMI'],
            'Natm': c['NATM'],
            'Vwmetcm': c['Vento'],
            'Azwmetcm': c['Direcao'],
            'Tent': c['Temp'],
            'Pent': c['Press'],
            'Elev_tiro': c['Elevacao'],
            'Azim_tiro': c['Azimute'],
            'Fusetime_input': c['Tempo'], # TODO: conferir se 'Tempo' eh 'Fusetime'
            'Sec_bal': c['SECBAL'],
            'Vweth': c['Wx_th'],
            'Vwnth': c['Wy_th'],
            'Vweff': c['Wx_ff'],
            'Vwnff': c['Wy_ff'],
            'RefDir': 0.0, # TODO: encontrar valor no log para 'RefDir'
        }

        teng = {
            'Delta_x': c['Delta_x_e_i'],
            'Delta_y': c['Delta_y_e_i'],
            'Delta_z': c['Delta_z_e_i'],
            'Delta_vx': c['Delta_vx_e_i'],
            'Delta_vy': c['Delta_vy_e_i'],
            'Delta_vz': c['Delta_vz_e_i'],
            'Cd_fac': c['Cd_fac_e_i'],
            'Cdsm_fac': c['Cdsm_fac_e_i'],
            'Thrust_fac': c['Thrust_fac_e_i'],
            'Tubetime': c['Tubetime_e_i'],
            'Delta_ejec': c['Delta_eject_e_i'],
            'Mass': c['Mass_e_i'],
            'Propmass': c['Propmass_e_i'],
            'Hejec': c['Hejec_e_i']
        }


        self.fog = c['Foguete']
        self.tiro    = tiro
        # self.teng    = teng
        self.__tiro0 = tiro
        self.__teng0 = teng

        return D


    def get_voo(self, fuze = 0.0):
        # guardando valor de 'rec'
        rec_ = self.rec

        # alterar apenas se o 'rec' == 0
        if (rec_ == 0):
            self.rec = 1
        
        # fazer um voo com as condicoes de tiro atuais
        fuze_ = self.fuze
        self.fuze = fuze
        self.voar_completo_fuze()
        
        # lendo dados de voo
        D = self.__get_voo_helper()

        # restaurando 'rec'
        self.rec = rec_
        self.fuze = fuze_

        # retorno da funcao
        return D
    
    def get_voo_extrap(self, c0 = -1):
        rec_ = self.rec

        if c0 == -1:
            c0 = self.get_tratar_dados_legacy()['inicio']

        self.rec = 1
        self.voar_extrapolando(c0)
        v = self.__get_voo_helper()
        
        if len(v) == 0:
            v = self.get_voo().head(1).apply(lambda x: x*0.)

        self.rec = rec_
        return v

    def __get_voo_helper(self):
        V     = nedt_engine.get_voo(self.__model)
        
        # gerando 'DataFrame' dos dados
        dados = np.column_stack([V['t'],V['x'],V['y'],V['z'],V['vx'],V['vy'],V['vz']])
        D     = pd.DataFrame(dados, columns = ['t','x','y','z','vx','vy','vz'])

        # calculando coordenadas 'norte' e 'este'
        azi       = self.tiro['Azim_tiro']*np.pi/3200.
        D['e']    = D.x*np.cos(azi) + D.y*np.sin(azi)
        D['n']    = -D.x*np.sin(azi) + D.y*np.cos(azi)
        
        # calculando 'vtot' e 'alc', criando 'h'
        D['vtot'] = np.hypot(np.hypot(D.vx,D.vy), D.vz)
        D['alc']  = np.hypot(D.x,D.y)
        D['h']    = D.z

        return D

    def get_radar(self):
        
        # encontrando inicio
        ini = 1
        if 'window' not in self.trackdata:
            ini = self.trackdata[self.trackdata.missionstate == 'Lock_On'].index[0]
        
        # lendo dados
        tk  = self.trackdata[ini:]
        
        azi = self.trackconfig['azimute'][0] * np.pi/3200.0
        
        # tempo
        t =   tk.relative_time / 1000.
        
        # pos
        x =   tk.filtered_pos_x
        y =   tk.filtered_pos_y
        e =   x * np.cos(azi) + y * np.sin(azi)
        n =  -x * np.sin(azi) + y * np.cos(azi)
        z =   tk.filtered_pos_z
        
        # vel
        vx =   tk.filtered_vel_x
        vy =   tk.filtered_vel_y
        vz =   tk.filtered_vel_z
        
        # covar
        covx = tk.one_sigma_x
        covy = tk.one_sigma_y
        covz = tk.one_sigma_z

        D = pd.DataFrame(np.column_stack([t, x, y, z, e, n, vx, vy, vz, covx, covy, covz]), columns=['t', 'x', 'y', 'z', 'e', 'n', 'vx', 'vy', 'vz', 'covx', 'covy', 'covz'])
        
        D['h']     = D.z
        D['alc']   = np.hypot(D.x, D.y)
        D['vtot']  = np.sqrt(D.vx*D.vx + D.vy*D.vy + D.vz*D.vz)
        D['covar'] = np.sqrt( (D.covx**4 + D.covy**4 + D.covz**4) / (D.covx**2 + D.covy**2 + D.covz**2) )
        
        return D
    
    def get_tratar_dados_legacy(self):
        c0 = nedt_engine.get_tratar_dados_legacy(self.__model)
        
        c0['C0_fq']     = [*c0['C0_fq']]
        c0['C0_extrap'] = [*c0['C0_extrap']]

        c0['inicio'] = {
            'extrapolar' : 1,
            'tempo' : c0['C0_extrap'][0],
            'pos' : c0['C0_extrap'][1:4],
            'vel' : c0['C0_extrap'][4:7],
        }

        return c0

    def get_tratar_dados(self):
        c0 = nedt_engine.get_tratar_dados(self.__model)
        c0['fq']     = [*c0['fq']]
        c0['extrap'] = [*c0['extrap']]

        # c0['janela_extrap'] = {c0['janela_extrap']}

        # calculando alcance associado a janela
        rr = self.get_radar()
        tini = c0['janela_extrap'][0]
        tfim = c0['janela_extrap'][1]
        
        r  = rr[(rr.t >= tini) & (rr.t <= tfim)]

        janela_alc = [r.alc.values[0], r.alc.values[-1]]
        c0['janela_extrap_alc'] = janela_alc

        c0['inicio'] = {
            'extrapolar' : 1,
            'tempo' : c0['extrap'][0],
            'pos' : c0['extrap'][1:4],
            'vel' : c0['extrap'][4:7],
        }

        return c0

    def get_tempo_janela_extrap(self):
        ci = self.get_tratar_dados()['janela_extrap']
        return ci

    def get_empuxo(self):
        bdt = self.bdt

        eref = bdt['Emp']
        N    = bdt['N_points']

        t    = bdt['T_emp_step'][0:N]/4.
        e    = bdt['P_emp_tp_1'][0:N]*eref

        return (t, e)

    def get_impulsao_total(self):
        # lendo valor ajustado da curva de empuxo
        emp  = self.get_empuxo()
        
        # calculando integral e convertendo de N.s para Kgf.s
        itot = np.trapz(emp[1], emp[0]) / 9.80665
        return itot
        
    def get_condicao_inicial_from_pos(self, pos = -1):
        
        r_ = self.get_radar()
        r  = r_[pos:pos+1]
        
        if len(r) == 0:
            r = r_.tail(1)

        inicio = {
            'extrapolar': 1,
            'tempo': r.t.values[0], 
            'pos': [r.x.values[0], r.y.values[0], r.z.values[0]],
            'vel': [r.vx.values[0], r.vy.values[0], r.vz.values[0]]
        }

        return inicio

    def get_condicao_inicial_from_tempo(self, tempo):
        
        r_ = self.get_radar()
        r  = r_[r_.t >= tempo].head()
        
        if len(r) == 0:
            r = r_.tail(1)

        inicio = {
            'extrapolar': 1,
            'tempo': r.t.values[0], 
            'pos': [r.x.values[0], r.y.values[0], r.z.values[0]],
            'vel': [r.vx.values[0], r.vy.values[0], r.vz.values[0]]
        }
        return inicio
    
    def get_condicao_inicial_from_alcance(self, alcance):
        
        r_ = self.get_radar()
        r  = r_[r_.alc >= alcance].head()
        
        if len(r) == 0:
            r = r_.tail(1)

        inicio = {
            'extrapolar': 1,
            'tempo': r.t.values[0], 
            'pos': [r.x.values[0], r.y.values[0], r.z.values[0]],
            'vel': [r.vx.values[0], r.vy.values[0], r.vz.values[0]]
        }

        return inicio

    def rec_clear(self):
        nedt_engine.rec_clear(self.__model)

    def plot_bdt_empuxo(self):
        t,e = self.get_empuxo()
        plt.plot(t,e)
        plt.grid(True)
    
    def plot_bdt_cwss(self, label=None):
        mach = np.arange(0., 4.1, 0.1)
        plt.plot(mach, self.bdt['Cwss'], marker='o', label=label)
        plt.grid(1)
        plt.xlabel('Mach')
        plt.ylabel('Cwss')


    def plot_voo_alcance(self, label=None, color=None, extrap=False):
        
        v = self.get_voo()

        h = plt.plot(v.alc, v.z, label=label, color=color)
        
        if self.secb > 0:
            ejec = self.get_ejecao()
            plt.plot(ejec[0], ejec[1], 'o', color=h[0].get_color(), label='ejecao')

        if extrap:
            if self.secb == 0:
                # se foguete eh HE, destacar ultimo ponto
                ej = (v.alc.values[-1], v.h.values[-1])
            else:
                # se foguete eh MW, destacar ejecao
                ej = self.get_ejecao()

            # plotando descaque
            plt.plot(ej[0], ej[1], 'o', color=h[0].get_color())
        
        txt = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, v.z.max(), v.alc.max())
        plt.title(txt)
        plt.xlabel('alcance [m]')
        plt.ylabel('altitude [m]')
        plt.grid(True)
        return h
    
    def plot_voo_alcance_extrap(self, c0 = -1, linewidth=None, label=None, title=None):
        r  = self.get_radar()
        v  = self.get_voo_extrap(c0)

        if label:
            label = label
        else:
            label = f'extrap. (tini: {v.t.values[0]:.1f}s, alc: {v.alc.values[-1]:.1f}m)'

        h = plt.plot(v.alc, v.z, linewidth=linewidth, label=label)
        plt.plot(v.alc.values[0], v.z.values[0], 'o', color=h[0].get_color(), linewidth=linewidth)
        plt.plot(v.alc.values[-1], v.z.values[-1], 'o', color=h[0].get_color(), linewidth=linewidth)

        if not title:
            title = f'fog: {self.fog}, apo: {r.h.max():.1f}m, range: {v.alc.values[-1]:.1f}m'
        
        plt.title(title)

        plt.xlabel('alcance [m]')
        plt.ylabel('altitude [m]')
        plt.grid(True)
        return h
    
    def plot_voo_en(self, show_alvo = False):
        v = self.get_voo()

        plt.plot(v.e, v.n)
        if show_alvo:
            alvo = np.subtract(self.alvo, self.lmu)
            plt.plot(alvo[0], alvo[1], 'x')

        txt = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, v.z.max(), v.alc.max())
        plt.title(txt)
        plt.xlabel('Este [m]')
        plt.ylabel('Norte [m]')
        plt.grid(True)

    def plot_voo_narigao(self):
        v = self.get_voo()

        plt.plot(v.z, v.vtot)
        txt = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, v.z.max(), v.alc.max())
        plt.title(txt)
        plt.xlabel('altitude [m]')
        plt.ylabel('velocidade total [m/s]')
        plt.grid(True)

    def plot_radar_en(self):
        r = self.get_radar()
        
        plt.plot(r.e, r.n)
        txt = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, r.z.max(), r.alc.max())
        plt.title(txt)
        plt.xlabel('alcance [m]')
        plt.ylabel('altitude [m]')
        plt.grid(True)
    
    def plot_radar_alcance(self, title=None, label=None, label_fim=None, extrap=False, linewidth=2):
        r = self.get_radar()
        
        if not label:
            label = 'rastreio'
        
        if not label_fim:
            label_fim = 'fim rastreio'

        h = plt.plot(r.alc, r.z, linewidth=linewidth, label=label)
        plt.plot(r.alc.values[-1], r.z.values[-1], 'o', label=label_fim, color = h[0].get_color())

        if extrap:
            self.plot_voo_alcance_extrap(linewidth=linewidth)

        if not title:
            title = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, r.z.max(), r.alc.max())

        plt.title(title)
        plt.xlabel('alcance [m]')
        plt.ylabel('altitude [m]')
        plt.grid(True)
        plt.legend()

        return h

    def plot_radar_covar(self, linewidth=None, extrap=False, label_values=False, label_region=False, label_ejec=False):
        r = self.get_radar()

        if not label_values:
            label_values = 'covariancia'

        if not label_region:
            label_region = 'regiao de escolha da ejecao'

        plt.plot(r.alc, r.covar, linewidth=linewidth, label=label_values)

        # destaque janela de extrapolacao
        if extrap:
            
            tempo_janela = self.get_tempo_janela_extrap()
            r_jan = r[(r.t >= tempo_janela[0]) & (r.t <= tempo_janela[1])]
            a_jan = (r_jan.alc.values[0], r_jan.alc.values[-1])
            
            covmin = r.covar.min()
            covmax = r.covar.max()

            plt.fill_between(a_jan, covmin, covmax, alpha=0.2, label=label_region)
            ci = self.get_tratar_dados_legacy()
            t0 = ci['inicio']['tempo']
            a0 = np.linalg.norm(ci['inicio']['pos'][0:2])

            if not label_ejec:
                label_ejec = f'ejecao: {t0:.1f}s'
            plt.plot([a0, a0], [0., covmax], linewidth=linewidth, label=label_ejec)


        plt.grid(True)

    def plot_radar_alcance_covar(self, label=None, extrap=True, linewidth=None):
        # FIX: get_tratar_dados e get_tratar_dados_legacy estao diferentes para o.load_track_file('ICA2019/ss60_2.txt')

        fig = plt.figure()
        gs  = fig.add_gridspec(4,1)

        # ALCANCE
        fig.add_subplot(gs[0:-1, :])
        self.plot_radar_alcance(label=label, extrap=extrap, linewidth=linewidth)
        xlim = plt.xlim()
        fig.add_subplot(gs[-1, :])

        # COVAR
        self.plot_radar_covar(extrap=1, linewidth=linewidth)

        plt.xlim(xlim)

        plt.legend(loc="upper left")


    def plot_radar_narigao(self):
        v = self.get_radar()

        plt.plot(v.z, v.vtot)
        txt = 'fog: {}, apo: {:.1f}, range: {:.1f}'.format(self.fog, v.z.max(), v.alc.max())
        plt.title(txt)
        plt.xlabel('altitude [m]')
        plt.ylabel('velocidade total [m/s]')
        plt.grid(True)

    def plot_comparacao_narigao(self, title=None):
        self.plot_radar_narigao()
        self.plot_voo_narigao()
        
        if not title:
            title = f'Comparacao traj. Altitude X Velocidade ({self.fog})'

        plt.title(title)

        plt.legend(['rastreio', 'simulacao'])

    def plot_comparacao_alcance_narigao(self, labels=[None, None], title=None):
        if not title:
            title = ['Alcance vs Altitude', 'Altitude vs Velocidade']

        plt.subplot(1,2,1)
        self.plot_comparacao_alcance(labels=labels, title=title[0])
        plt.subplot(1,2,2)
        self.plot_comparacao_narigao(title=title[1])

    def plot_comparacao_alcance(self, labels=[None, None], extrap=False, title=None):
        
        if labels[0] == None:
            labels[0] = 'rastreio'
            
        if labels[1] == None:
            labels[1] = 'simulacao'

        self.plot_radar_alcance(label=labels[0], extrap=extrap)
        self.plot_voo_alcance(label=labels[1], extrap=extrap)
        
        plt.legend()

        if not title:
            title = f'Comparacao traj. Alcance X Altitude ({self.fog})'

        plt.title(title)

    def plot_ventos(self, escala = 20.0, ncam = -1):
        met = self.trackconfig['metcm']
        h = [0, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 
             11000, 12000, 13000, 14000, 15000, 16000, 17000, 18000, 19000, 20000, 21000, 22000, 23000]

        vel = np.multiply(met['vel'], escala)
        azi = np.multiply(met['azi'], np.pi/3200.)
        
        numel = len(azi)
        h     = h[0:numel]

        if (ncam > 0) and (ncam < numel):
            numel = ncam
            h   = h[0:numel]
            vel = vel[0:numel]
            azi = azi[0:numel]

        # h   = np.ones((numel, 1))*2000
        # azi = np.linspace(0., 2.*np.pi, numel, endpoint=False)

        colors = azi
        
        normalize = matplotlib.colors.Normalize(vmin=0., vmax=2.*np.pi)
        cmap = 'hsv'

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='polar')
        c = ax.scatter(azi, h, s=vel, c=colors, cmap=cmap, alpha=1.0, norm=normalize)
        ax.set_rorigin(0)
        ax.set_theta_direction(-1)
        ax.set_theta_zero_location('W', offset=-90)

        n = 16
        ax.set_xticks(np.linspace(0., 2.0*np.pi, n, endpoint=False))
        ax.set_xticklabels(map(int, np.linspace(0, 6400, n, endpoint=False)))

        # legenda
        handles, labels = c.legend_elements(prop='sizes', alpha=0.6)
        labels_nro = [float(re.findall(r'\d+', la)[0]) for la in labels]
        labels_txt = [r'$\mathdefault{'+f'{nro/escala:.1f}'+r'}$' for nro in labels_nro]

        ax.legend(handles, labels_txt, loc='upper right', title='velocidade', bbox_to_anchor=(1.35,1.0))

    def get_ponto_extrap_legacy(self):
        extrap = nedt_engine.get_tratar_dados_legacy(self.__model)
        
        erro = extrap['erro']
        tempo = extrap['C0_extrap'][0]
        pos = extrap['C0_extrap'][1:4]
        vel = extrap['C0_extrap'][4:]
        
        return {'erro':erro, 'tempo':tempo, 'pos':pos, 'vel':vel}

    def get_ponto_extrap(self):
        return nedt_engine.get_ponto_extrap(self.__model)

    def load_met(self, addr):
        import os

        # testando se `addr` existe
        addr_ = addr
        if not os.path.exists(addr_):
            addr_ = f'py/{addr_}'
            if not os.path.exists(addr_):
                print(f'endereco \'{addr}\' nao existe, abortando operacao!')
                return 0
            addr = addr_

        # gerando padrao de dados arquivo `met`
        format_pat = re.compile(
            r"(?P<cam>\d{2})"
            r"(?P<azi>\d{3})"
            r"(?P<vel>\d{3})\s"
            r"(?P<temp>\d{4})"
            r"(?P<press>\d{4})"
        )

        # lendo arquivo `met`
        with open(addr, 'r') as f:
            
            # inicializando vetores de dados
            vel   = []
            azi   = []
            temp  = []
            press = []

            # lendo linhas
            for line in f:
                match = format_pat.match(line)

                # lendo resultados com `match`
                if match:
                    g = match.groupdict()
                    azi.append(float(g['azi'])*10)
                    vel.append(float(g['vel']))
                    temp.append(float(g['temp'])/10)
                    press.append(float(g['press']))

        # calculando numero de camadas
        natm = len(vel) - 1

        # gravando valores no objeto
        self.tiro = {'Natm': natm}
        self.tiro = {'Metcm_included': 1}
        self.tiro = {'Azwmetcm': azi}
        self.tiro = {'Vwmetcm': vel}
        self.tiro = {'Tent': temp}
        self.tiro = {'Pent': press}

        return 1


    def set_tiro_nominal(self, alt = 0.0, temp = 15.0, press = 1013.25):
        # TODO: colocar atmos isa se entrar apenas com 'ALT'
        self.tiro = {
            'T0': temp,
            'Proptemp': temp,
            'P0': press,   

            'Elau': 0.0,
            'Nlau': 0.0,
            'Alt_launch': alt,

            'Altfg': alt,
            'Alt_met': alt,
            'Altarg': alt,

            'Fusetime_input': 0.0,
            
            # ventos
            'Vws': 0.0,
            'Azws': 0.0,
            'Metcm_included': 0,
            'Natm': 0,
            'Vwmetcm': [0.],
            'Azwmetcm': [0.],
            'Tent': [296.0, 295.1, 293.9, 291.6, 288.8, 286.1, 283.1, 280.5, 277.8, 275.6, 273.2, 269.6, 265.9, 263.1],
            'Pent': [0.],
            'Vweth': 0.0,
            'Vwnth': 0.0,
            'Vweff': 0.0,
            'Vwnff': 0.0,
            'RefDir': 0.0
        }


    def get_bdt_eminmax(self):
        return (self.bdt['Elev_min'], self.bdt['Elevmax']/0.05625)

    def print_tiro(self): 

        tiro = self.tiro

        print('{')
        for t in tiro:
            if np.isscalar(tiro[t]):
                print('\t\'{}\': {},'.format(t, tiro[t]))
            else:
                nro = tiro['Natm'] + 1
                vet = ', '.join(['{}'.format(v) for v in tiro[t]][0:nro])
                print('\t\'{}\': [{}],'.format(t, vet))

        print('}')
    
    def print_config(self, nome = None):
        
        # lendo valor de 'tiro'
        tiro = self.tiro
        
        # ajustando titulo dados
        if not nome:
            nome = f'dados config {self.fog}'

        nome_ = nome.upper().replace(' ','_')
        print(f'{nome_}:')
        
        for t in tiro:
            # ajuste dados de 'MET'
            if t in ['Vwmetcm', 'Azwmetcm', 'Tent', 'Pent']:
                tiro[t] = [x for x in tiro[t][:self.natm+1]]

            # imprimindo valor
            t_ = f'{t:15}'.replace(' ','.')
            print(f'{t_}: ', tiro[t])

    def print_cpp(self, copy = False):
        nedt_print.print_cpp(self, copy = copy)

    def ajuste_pos_voo(self, obj = 'o'):
        self.reset_tiro()
        self.reset_estimativa_ventos()

        ci = self.get_tratar_dados_legacy()['inicio']['pos']
        aref = np.linalg.norm(ci[0:2])
        href = ci[2]
        a = 0.96
        b = 1.04
        for _ in range(20):
            # valor funcao
            x = (a + b)/2.0
            
            # simulacao
            self.teng_th = x
            self.set_apogeu_radar()
            v = self.get_voo()
            
            # calculando erro dif. ponto
            vv = v[v.alc >= aref].head(1)
            h  = vv.h.values[0]
            erro = h - href
            
            # ajuste janela
            if erro > 0.:
                b = x
            else:
                a = x
            # condicao de saida
            if abs(erro) < 1.0:
                break

        # correcao azimute
        # TODO: colocar esse calculo na iteracao de busca, alinhando o apogeu da trajetoria
        dazi  = self.trackconfig['desvio_lateral'][0]/self.get_dist_impacto_track()*1000.
        self.azi = self.trackconfig['azimute'][0] + dazi

        delev = self.elev - self.trackconfig['elevacao'][0]
        
        if delev > 0.:
            sig_elev = '+'
        else:
            sig_elev = '-'
        
        if dazi > 0.:
            sig_azi = '+'
        else:
            sig_azi = '-'

        tiro0 = self.get_tiro0()
        elev0 = tiro0['Elev_tiro']
        azi0 = tiro0['Azim_tiro']

        print(f'{obj}.teng_th = {self.teng_th:0.3f}')    
        print(f'{obj}.elev    = {elev0:0.1f} {sig_elev} {abs(delev):.1f}')
        print(f'{obj}.azi     = {azi0:0.2f} {sig_azi} {abs(dazi):.1f}')
        res = {
            'empuxo': self.teng_th,
            'elev': self.elev,
            'azi': self.azi,
            'delev': delev,
            'dazi': dazi
        }
        return res
    def calc_densidade(self, temperatura = -999., pressao = -999.):
        if temperatura < -990.:
            temperatura = self.temp
            
        if pressao < -990.:
            pressao = self.pressao
            
        densidade = pressao*100/287.058/(temperatura + 273.15)
        return densidade

    def load_estados(self, addr = None):
        if not addr:
            addr = 'C:\\Users\\avibras\\Desktop\\DADOS_FTSA2020\\TRAJ\\estados.txt'

        D = pd.read_table(addr, delimiter='\s+')

        D.columns = ['Tempo', 'Vxh', 'Vyh', 'Vzh', 'Phi', 'Teta', 'Psi', 'Wx', 'Wy', 'Wz', 'Rxr', 'Ryr', 'Z', 'Dlat', 'Dlong', 'Vx', 'Vy', 'Vz', 'Qt1', 'Qt2', 'Qt3', 'Qt4', 'Vx_p', 'Vy_p', 'Vz_p', 'Sm', 'Cma', 'Cna', 'Mach', 'Cfx', 'F_trans', 'Tpx', 'Alfab', 'Pd', 'Xcm', 'Massa', 'Fax', 'Fay', 'Faz', 'Max', 'May', 'Maz', 'Frx', 'Fry', 'Frz', 'Mrx', 'Mry', 'Mrz']
        D['teta_deg'] = D.Teta.mul(180./np.pi)
        D['vtot'] = np.sqrt(D.Vx**2 + D.Vy**2 + D.Vz**2)
        D['vtot_mach'] = D.vtot.div(340.)
        return D

    def version(self):
        return 'v3.2.0'

    
    
